cd /root/autodl-tmp/Multi-Watermarking/Code/MBRS
conda activate mbrs

tensorboard --logdir ./fine_tuning/log