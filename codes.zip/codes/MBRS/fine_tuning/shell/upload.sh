export PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/MBRS && \

cd $PROJECT_PATH && \
7z a MBRS-weight.7z \
"results/MBRS_m64_Combined([JpegMask(50),Jpeg(50),Identity()])__2025_07_27__17_44_08/images" \
"results/MBRS_m64_Combined([JpegMask(50),Jpeg(50),Identity()])__2025_07_27__17_44_08/models/D_19.pth" \
"results/MBRS_m64_Combined([JpegMask(50),Jpeg(50),Identity()])__2025_07_27__17_44_08/models/EC_19.pth" \
"results/MBRS_m64_Combined([JpegMask(50),Jpeg(50),Identity()])__2025_07_27__17_44_08/train_log.txt" \
"results/MBRS_m64_Combined([JpegMask(50),Jpeg(50),Identity()])__2025_07_27__17_44_08/train_params.txt" \
"results/MBRS_m64_Combined([JpegMask(50),Jpeg(50),Identity()])__2025_07_27__17_44_08/val_log.txt" && \
rclone copy MBRS-weight.7z gdrive:ModelWeights -P && \
rm MBRS-weight.7z