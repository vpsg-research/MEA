export PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/MBRS

cd $PROJECT_PATH
# ! Remove env
conda activate base
conda env remove -n mbrs --all -y
# ! Create env
conda activate base && \
conda env remove -n mbrs -y
mamba create -n mbrs python=3.7 -y && \
conda activate mbrs && \
# mamba install pytorch==1.5.0 torchvision cudatoolkit=10.2 -c pytorch -y && \
mamba install kornia==0.3.0 numpy Pillow scipy tensorboard pandas tabulate tqdm pyyaml transformers -c conda-forge -y && \
pip install torchvision "markdown<3.2" "tensorboard<2.5" lpips scikit-image