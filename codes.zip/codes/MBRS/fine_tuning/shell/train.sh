export PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/MBRS

cd $PROJECT_PATH
conda activate mbrs

python train.py