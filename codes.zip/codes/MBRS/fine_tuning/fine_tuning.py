from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
import pandas as pd
import time
import sys
import os
sys.path.append(os.getcwd())

from utils import *
from Network import *
from MBRSConfig import MBRSConfig

def add_summary(writer, loss_dict, step, category):
    for key in loss_dict:
        writer.add_scalar(category + "/" + key, loss_dict[key], step)

def main():
    # Init dataset
    train_dataset = MBRSDataset(os.path.join(config.deprecated_config.dataset_path, "train"), config.deprecated_config.H, config.deprecated_config.W)
    train_dataloader = DataLoader(train_dataset, batch_size=config.deprecated_config.batch_size, shuffle=True, num_workers=0, pin_memory=True)
    val_dataset = MBRSDataset(os.path.join(config.deprecated_config.dataset_path, "val"), config.deprecated_config.H, config.deprecated_config.W)
    val_dataloader = DataLoader(val_dataset, batch_size=config.deprecated_config.batch_size, shuffle=False, num_workers=0, pin_memory=True)
    
    # Init network
    network = FineTuningNetwork(
        config.deprecated_config.H, 
        config.deprecated_config.W, 
        config.deprecated_config.message_length, 
        config.deprecated_config.noise_layers, 
        device, 
        config.deprecated_config.batch_size, 
        config.deprecated_config.lr,
        num_warmup_steps=len(train_dataloader)*0.1, 
        num_training_steps=len(train_dataloader)*5, 
        with_diffusion=config.deprecated_config.with_diffusion
    )
    network.load_model(config.weight_path.encoder_decoder_origin, config.weight_path.discriminator_origin)

    print("\nStart fine tuning: \n\n")

    for epoch in tqdm(
        range(
            config.deprecated_config.epoch_number, 
            config.deprecated_config.epoch_number + config.number_epoch_total + 1
        ), 
        total=config.number_epoch_total
    ):
        running_result = {
            "error_rate": 0.0,
            "psnr": 0.0,
            "ssim": 0.0,
            "g_loss": 0.0,
            "g_loss_on_discriminator": 0.0,
            "g_loss_on_encoder": 0.0,
            "g_loss_on_decoder": 0.0,
            "d_cover_loss": 0.0,
            "d_encoded_loss": 0.0, 
            # Double watermark
            "g_loss_on_double_watermark": 0.0, 
            "double_error_rate": 0.0,
            "double_psnr": 0.0,
            "double_ssim": 0.0
        }

        start_time = time.time()
        num = 0
        for _, images, in tqdm(enumerate(train_dataloader), total=len(train_dataloader)):
            
            image = images.to(device)
            message = torch.Tensor(np.random.choice([0, 1], (image.shape[0], config.deprecated_config.message_length))).to(device)

            result = network.train(image, message)

            for key in result:
                running_result[key] += float(result[key])
                
            # Log on tensorboard
            add_summary(writer, result, epoch * len(train_dataloader) + num, "train_on_total_step")
            writer.add_scalar('lr', network.scheduler.get_last_lr()[0], epoch * len(train_dataloader) + num)

            num += 1

        # ============================ train results ============================ #
        for key in running_result:
            writer.add_scalar("train_on_epoch/" + key, running_result[key] / num, epoch)

        # ============================== validation ============================= #
        val_result = {
            "error_rate": 0.0,
            "psnr": 0.0,
            "ssim": 0.0,
            "g_loss": 0.0,
            "g_loss_on_discriminator": 0.0,
            "g_loss_on_encoder": 0.0,
            "g_loss_on_decoder": 0.0,
            "d_cover_loss": 0.0,
            "d_encoded_loss": 0.0, 
            # Double watermark
            "g_loss_on_double_watermark": 0.0, 
            "double_error_rate": 0.0,
            "double_psnr": 0.0,
            "double_ssim": 0.0
        }

        start_time = time.time()

        saved_iterations = np.random.choice(np.arange(len(val_dataloader)), size=config.deprecated_config.save_images_number, replace=False)
        saved_all = None

        num = 0
        for i, images in enumerate(val_dataloader):
            image = images.to(device)
            message = torch.Tensor(np.random.choice([0, 1], (image.shape[0], config.deprecated_config.message_length))).to(device)

            result, (images, encoded_images, noised_images, messages, decoded_messages) = network.validation(image, message)

            for key in result:
                val_result[key] += float(result[key])

            add_summary(writer, result, epoch * len(val_dataloader) + num, "val_on_total_steps")

            num += 1

            if i in saved_iterations:
                if saved_all is None:
                    saved_all = get_random_images(image, encoded_images, noised_images)
                else:
                    saved_all = concatenate_images(saved_all, image, encoded_images, noised_images)

        save_images(saved_all, epoch, config.deprecated_config.result_folder + "images/", resize_to=(config.deprecated_config.W, config.deprecated_config.H))

        # ========================== validation results ========================= #
        content = "Epoch " + str(epoch) + " : " + str(int(time.time() - start_time)) + "\n"
        for key in val_result:
            content += key + "=" + str(val_result[key] / num) + ","
            writer.add_scalar("val_on_epoch/" + key, val_result[key] / num, epoch)
        content += "\n"

        # ============================== save model ============================= #
        path_model = config.deprecated_config.result_folder + "models/"
        path_encoder_decoder = path_model + "EC_double_" + str(epoch) + ".pth"
        path_discriminator = path_model + "D_double_" + str(epoch) + ".pth"
        network.save_model(path_encoder_decoder, path_discriminator)

if __name__ == '__main__':
    project_name = "FullFineTuningWithOnlyMessage"
    
    description = (
        "1. Only double message loss is applied.<br/>" + 
        "2. At second forwarding, forward process is wrapped by eval() and train() to freeze BN parameters."
    )
    
    loss_code = (
'''```Python
g_loss_on_double_watermark = (
    # self.destruction_criterion(double_encoded_images.detach(), encoded_images) * self.destructive_weight + # Deconstruct image
    # self.criterion_MSE(double_encoded_images.detach(), torch.zeros_like(encoded_images)) * self.destructive_weight + # Deconstruct image
    # self.criterion_MSE(double_encoded_images, images) * self.destructive_weight + # Maintaining image quality
    self.criterion_MSE(double_decoded_messages, messages) * self.double_decoded_message_weight
)
```'''
    )
    
    config = MBRSConfig()
    writer = SummaryWriter(log_dir=f"fine_tuning/log/{project_name}")
    writer.add_text("profile", pd.DataFrame({
        "project_name": project_name, 
        "description": description,
        "result_folder": config.deprecated_config.result_folder,
        "time": time.strftime("%Y-%m-%d %H %M %S", time.localtime()),
        "batch_size": config.deprecated_config.batch_size,
        "lr": config.deprecated_config.lr,
        "epoch_number": config.deprecated_config.epoch_number,
        "message_length": config.deprecated_config.message_length,
        "noise_layers": config.deprecated_config.noise_layers,
        "with_diffusion": config.deprecated_config.with_diffusion,
        "only_decoder": config.deprecated_config.only_decoder,
        "train_continue": config.deprecated_config.train_continue,
        "train_continue_path": config.deprecated_config.train_continue_path,
        "train_continue_epoch": config.deprecated_config.train_continue_epoch,
        "save_images_number": config.deprecated_config.save_images_number,
        "dataset_path": config.deprecated_config.dataset_path
    }).T.reset_index().rename(columns={"index": "key", 0: "value"}).to_markdown(index=False))
    
    writer.add_text("loss_code", loss_code)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    main()
    writer.close()