from torchvision import transforms
import yaml
from PIL import Image
from torch.utils.data import DataLoader
from tqdm import tqdm
import lpips
import torch
import sys
import os
sys.path.append(os.getcwd())
sys.path.append(os.path.dirname(os.getcwd()))

from multi_encoding_test.Test import MultiEnTester, getImageOrigin
from utils import *
from Network import *
from MBRSConfig import MBRSConfig
            
class Tester(MultiEnTester):
    def __init__(self, name, network_origin, network_double, test_loader, CustomDataset):
        super().__init__(name, network_origin, network_double, test_loader, CustomDataset)
        
    def calculate_bit_error_rate(self, original_message: torch.Tensor, decoded_message: torch.Tensor) -> float:
        return self.network_double.decoded_message_error_rate_batch(original_message, decoded_message)
    
    def generate_message(self, batch_size: int, message_length: int) -> torch.Tensor:
        return torch.Tensor(np.random.choice([0, 1], (batch_size, message_length)))
    
    def get_psnr(self, original_image: torch.Tensor, encoded_image: torch.Tensor) -> float:
        return kornia.losses.psnr_loss(encoded_image.detach(), original_image, 2).item()

    def get_ssim(self, original_image: torch.Tensor, encoded_image: torch.Tensor) -> float:
        return 1 - 2 * kornia.losses.ssim(encoded_image.detach(), original_image, window_size=5, reduction="mean").item()
    
    def encode(self, network: FineTuningNetwork, image: torch.Tensor, message: torch.Tensor) -> torch.Tensor:
        return network.encoder_decoder.module.encoder(image, message)
    
    def decode(self, network: FineTuningNetwork, image: torch.Tensor):
        return network.encoder_decoder.module.decoder(image)
    
    def encode_decode(self, network, image: torch.Tensor, message: torch.Tensor):
        # return network.encoder_decoder.module.forward(image, message)
        encoded_images, noised_images, decoded_messages = network.encoder_decoder.module.forward(image, message)
        return noised_images, noised_images, decoded_messages
    
    def save_image(self, original_image: torch.Tensor, watermarked_image: torch.Tensor, multi_watermarked_image: torch.Tensor, name, encoding_num: int, repository: str=None):
        trans = transforms.Resize((256, 256))
        watermarked_image = trans(watermarked_image)
        multi_watermarked_image = trans(multi_watermarked_image)
        # Save batch
        for idx, n in enumerate(name):
            self.general_save_image(original_image[idx], os.path.join(repository, n), 'original.png')
            self.general_save_image(watermarked_image[idx], os.path.join(repository, n, 'watermarked'), f'{self.name}-1.png')
            self.general_save_image(multi_watermarked_image[idx], os.path.join(repository, n, 'watermarked'), f'{self.name}-{encoding_num}.png')
    
    def test_across_model_encode_specific(self, network, number_mutiple_encoding: int, type: str, name_model: str):
        for i, (image, name, message) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with encoding {number_mutiple_encoding} Testing'):
            batch_size = image.shape[0]
            image = image.to(network.device)
            message = self.generate_message(batch_size, network.message_length).to(network.device)
            encoded_images, noised_images, decoded_messages = self.encode_decode(network, image, message)
            
            # Add multiple watermark
            double_encoded_images = noised_images
            for j in range(number_mutiple_encoding):
                double_message = self.generate_message(batch_size, network.message_length).to(network.device)
                double_encoded_images, _, double_decoded_messages = self.encode_decode(network, double_encoded_images, double_message)
            
            for idx, n in enumerate(name):
                trans = transforms.Resize((256, 256))
                self.general_save_image(
                    trans(double_encoded_images[idx]), 
                    os.path.join(
                        self.result_adapter.common_result_folder, 
                        name_model, 
                        'repository',
                        type, 
                        n, 
                        'watermarked'
                    ), 
                    f"{self.name}-{number_mutiple_encoding}.png"
                )


class TestDataset(MBRSDataset):
    def __getitem__(self, index):
        image = Image.open(os.path.join(self.path, self.list[index])).convert("RGB")
        image = self.transform_image(image)
        return image, self.list[index][:-4], getImageOrigin(os.path.join(self.path, self.list[index]))

class RepoModelDataset(MBRSDataset): # image, name, message
    def __init__(self, path, H=256, W=256, name_model='MBRS', number_encode=1):
        super().__init__(path, H, W)
        self.name_model = name_model
        self.number_encode = number_encode
        self.transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5]), 
            transforms.Resize((128, 128))
        ])
    
    def __getitem__(self, index):
        image = Image.open(os.path.join(self.path, self.list[index], "watermarked", f"{self.name_model}-{self.number_encode}.png")).convert("RGB")
        image = self.transform(image)
        message = torch.from_numpy(np.load(os.path.join(self.path, self.list[index], "message.npy")))
        return image, self.list[index], message

if __name__ == '__main__':
    config = MBRSConfig()
    criterion_LPIPS = lpips.LPIPS().to("cuda")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tmp_noise_layers = config.deprecated_config.noise_layers.copy()
    print(config.deprecated_config.noise_layers)
    network = FineTuningNetwork(
        config.deprecated_config.H, 
        config.deprecated_config.W, 
        config.deprecated_config.message_length, 
        config.deprecated_config.noise_layers, 
        device, 
        config.deprecated_config.batch_size, 
        config.deprecated_config.lr
    )
    network.load_model(config.weight_path.encoder_decoder_origin, config.weight_path.discriminator_origin)

    double_network = FineTuningNetwork(
        config.deprecated_config.H, 
        config.deprecated_config.W, 
        config.deprecated_config.message_length, 
        tmp_noise_layers, 
        device, 
        config.deprecated_config.batch_size, 
        config.deprecated_config.lr
    )
    double_network.load_model(config.weight_path.encoder_decoder_multiple, config.weight_path.discriminator_multiple)

    test_dataset = TestDataset(os.path.join(config.deprecated_config.dataset_path, os.getenv("TEST_MODE")), config.deprecated_config.H, config.deprecated_config.W)
    test_dataloader = DataLoader(test_dataset, batch_size=config.deprecated_config.batch_size, shuffle=False, num_workers=0, pin_memory=True)
    
    tester = Tester("MBRS", network, double_network, test_dataloader, RepoModelDataset)
    
    tester.test(double_encoding_num=5)
        