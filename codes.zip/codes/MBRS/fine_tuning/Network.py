from network.Network import *
from transformers import get_cosine_schedule_with_warmup
from random import randint

def set_bn_track_running_stats(model, track_stats: bool):  
    for mod in model.modules():  
        if isinstance(mod, torch.nn.BatchNorm2d):  
            mod.track_running_stats = track_stats  

class FineTuningNetwork(Network):
    def __init__(self,  H, W, message_length, noise_layers, device, batch_size, lr, num_warmup_steps=10, num_training_steps=2000, with_diffusion=False, only_decoder=False, freezing_encoder=False, freezing_decoder=False):
        super().__init__(H, W, message_length, noise_layers, device, batch_size, lr, with_diffusion, only_decoder)
        self.message_length = message_length

        self.scheduler = get_cosine_schedule_with_warmup(self.opt_encoder_decoder, num_warmup_steps=num_warmup_steps, num_training_steps=num_training_steps)
        
        self.double_loss_weight = 10
        self.encoder_weight = 5
        self.double_decoded_message_weight = 1
        
    def train(self, images: torch.Tensor, messages: torch.Tensor):
        self.encoder_decoder.train()
        self.discriminator.train()
        # set_bn_track_running_stats(self.encoder_decoder, False)
        with torch.enable_grad():
            # use device to compute
            images, messages = images.to(self.device), messages.to(self.device)
            encoded_images, noised_images, decoded_messages = self.encoder_decoder(images, messages)
            # ======================= Double watermarking ====================== #
            double_encoded_images = encoded_images.clone()
            for i in range(1, randint(2, 6)):
                double_message = torch.Tensor(np.random.choice([0, 1], (images.shape[0], self.message_length))).to(self.device)
                double_encoded_images, _, double_decoded_messages = self.encoder_decoder(noised_images, double_message)

            # ========================= train discriminator ========================= #
            self.opt_discriminator.zero_grad()

            # RAW : target label for image should be "cover"(1)
            d_label_cover = self.discriminator(images)
            d_cover_loss = self.criterion_BCE(d_label_cover, self.label_cover[:d_label_cover.shape[0]])
            d_cover_loss.backward()

            # GAN : target label for encoded image should be "encoded"(0)
            d_label_encoded = self.discriminator(encoded_images.detach())
            d_encoded_loss = self.criterion_BCE(d_label_encoded, self.label_encoded[:d_label_encoded.shape[0]])
            d_encoded_loss.backward()

            self.opt_discriminator.step()

            # ====================== train encoder and decoder ====================== #
            self.opt_encoder_decoder.zero_grad()

            # GAN : target label for encoded image should be "cover"(0)
            g_label_decoded = self.discriminator(encoded_images)
            g_loss_on_discriminator = self.criterion_BCE(g_label_decoded, self.label_cover[:g_label_decoded.shape[0]])

            # RAW : the encoded image should be similar to cover image
            g_loss_on_encoder = self.criterion_MSE(encoded_images, images)

            # RESULT : the decoded message should be similar to the raw message
            g_loss_on_decoder = self.criterion_MSE(decoded_messages, messages)

            g_loss_on_double_watermark = (
                # self.destruction_criterion(double_encoded_images.detach(), encoded_images) * self.destructive_weight + # Deconstruct image
                # self.criterion_MSE(double_encoded_images.detach(), torch.zeros_like(encoded_images)) * self.destructive_weight + # Deconstruct image
                # self.criterion_MSE(double_encoded_images, images) * self.destructive_weight + # Maintaining image quality
                self.criterion_MSE(double_decoded_messages, messages) * self.double_decoded_message_weight
            )

            # full loss
            g_loss = (
                self.discriminator_weight * g_loss_on_discriminator + 
                self.encoder_weight * g_loss_on_encoder + 
                self.decoder_weight * g_loss_on_decoder + 
                self.double_loss_weight * g_loss_on_double_watermark
            )

            g_loss.backward()
            self.opt_encoder_decoder.step()
            self.scheduler.step()

            # psnr
            psnr = kornia.losses.psnr_loss(encoded_images.detach(), images, 2)
            double_psnr = kornia.losses.psnr_loss(double_encoded_images.detach(), images, 2)
            # ssim
            ssim = 1 - 2 * kornia.losses.ssim(encoded_images.detach(), images, window_size=5, reduction="mean")
            doube_ssim = 1 - 2 * kornia.losses.ssim(double_encoded_images.detach(), images, window_size=5, reduction="mean")

        # ====================== decoded message error rate ===================== #
        error_rate = self.decoded_message_error_rate_batch(messages, decoded_messages)
        double_error_rate = self.decoded_message_error_rate_batch(messages, double_decoded_messages)

        return {
            "error_rate": error_rate,
            "psnr": psnr,
            "ssim": ssim,
            "g_loss": g_loss,
            "g_loss_on_discriminator": g_loss_on_discriminator,
            "g_loss_on_encoder": g_loss_on_encoder,
            "g_loss_on_decoder": g_loss_on_decoder,
            "d_cover_loss": d_cover_loss,
            "d_encoded_loss": d_encoded_loss, 
            # ==================== Added double watermarking =================== #
            "g_loss_on_double_watermark": g_loss_on_double_watermark, 
            "double_error_rate": double_error_rate,
            "double_psnr": double_psnr,
            "double_ssim": doube_ssim
        }

    def validation(self, images: torch.Tensor, messages: torch.Tensor, encoding_num: int = 1):
        self.encoder_decoder.eval()
        self.discriminator.eval()
        # set_bn_track_running_stats(self.encoder_decoder, False)
        with torch.no_grad():
            # use device to compute
            images, messages = images.to(self.device), messages.to(self.device)
            encoded_images, noised_images, decoded_messages = self.encoder_decoder(images, messages)

            # ======================== validate discriminator ======================= #
            # RAW : target label for image should be "cover"(1)
            d_label_cover = self.discriminator(images)
            d_cover_loss = self.criterion_BCE(d_label_cover, self.label_cover[:d_label_cover.shape[0]])

            # GAN : target label for encoded image should be "encoded"(0)
            d_label_encoded = self.discriminator(encoded_images.detach())
            d_encoded_loss = self.criterion_BCE(d_label_encoded, self.label_encoded[:d_label_encoded.shape[0]])

            # ===================== validate encoder and decoder ==================== #
            # GAN : target label for encoded image should be "cover"(0)
            g_label_decoded = self.discriminator(encoded_images)
            g_loss_on_discriminator = self.criterion_BCE(g_label_decoded, self.label_cover[:g_label_decoded.shape[0]])

            # RAW : the encoded image should be similar to cover image
            g_loss_on_encoder = self.criterion_MSE(encoded_images, images)

            # RESULT : the decoded message should be similar to the raw message
            g_loss_on_decoder = self.criterion_MSE(decoded_messages, messages)

            # ======================= Double watermarking ====================== #
            double_encoded_images = noised_images
            for i in range(encoding_num): # In default, this will running 1 time
                double_message = torch.Tensor(np.random.choice([0, 1], (images.shape[0], self.message_length))).to('cuda')
                double_encoded_images, _, double_decoded_messages = self.encoder_decoder(double_encoded_images, double_message)
            g_loss_on_double_watermark = (
                # self.destruction_criterion(double_encoded_images.detach(), encoded_images) * self.destructive_weight + # Deconstruct image
                # self.criterion_MSE(double_encoded_images.detach(), torch.zeros_like(encoded_images)) * self.destructive_weight + # Deconstruct image
                # self.criterion_MSE(double_encoded_images, images) * self.destructive_weight + # Maintaining image quality
                self.criterion_MSE(double_decoded_messages, messages) * self.double_decoded_message_weight
            )

            # full loss
            g_loss = (
                self.discriminator_weight * g_loss_on_discriminator + 
                self.encoder_weight * g_loss_on_encoder + 
                self.decoder_weight * g_loss_on_decoder + 
                self.double_loss_weight * g_loss_on_double_watermark
            )
            
            # psnr
            psnr = kornia.losses.psnr_loss(encoded_images.detach(), images, 2)
            double_psnr = kornia.losses.psnr_loss(double_encoded_images.detach(), images, 2)
            # ssim
            ssim = 1 - 2 * kornia.losses.ssim(encoded_images.detach(), images, window_size=5, reduction="mean")
            doube_ssim = 1 - 2 * kornia.losses.ssim(double_encoded_images.detach(), images, window_size=5, reduction="mean")

        # ====================== decoded message error rate ===================== #
        error_rate = self.decoded_message_error_rate_batch(messages, decoded_messages)
        double_error_rate = self.decoded_message_error_rate_batch(messages, double_decoded_messages)    
        
        return {
            "error_rate": error_rate,
            "psnr": psnr,
            "ssim": ssim,
            "g_loss": g_loss,
            "g_loss_on_discriminator": g_loss_on_discriminator,
            "g_loss_on_encoder": g_loss_on_encoder,
            "g_loss_on_decoder": g_loss_on_decoder,
            "d_cover_loss": d_cover_loss,
            "d_encoded_loss": d_encoded_loss, 
            # ==================== Added double watermarking =================== #
            "g_loss_on_double_watermark": g_loss_on_double_watermark, 
            "double_error_rate": double_error_rate,
            "double_psnr": double_psnr,
            "double_ssim": doube_ssim
        }, (images, encoded_images, noised_images, messages, decoded_messages)