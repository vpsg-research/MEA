import time
import os



from utils.settings import JsonConfig

class MBRSConfig:
    def __init__(self):
        self._init_global_config()
        self._init_fine_tuning_config()
        self._init_test_fine_tuning_config()
        self._init_train_files()
    
    def _init_global_config(self):
        self.deprecated_config = JsonConfig()
        assert os.path.exists("train_settings.json"), "train_settings.json not found"
        self.deprecated_config.load_json_file("train_settings.json")
        self.number_epoch_total = 20
        
    def _init_fine_tuning_config(self):
        self.deprecated_config.epoch_number = 20
        self.deprecated_config.batch_size = 4
        self.deprecated_config.H = 128
        self.deprecated_config.W = 128
        self.deprecated_config.lr = 1e-4
    
    def _init_test_fine_tuning_config(self):
        self.weight_path = self.WeightPath()
        
    def _init_train_files(self):
        full_project_name = self.deprecated_config.project_name + "_m" + str(self.deprecated_config.message_length)
        for noise in self.deprecated_config.noise_layers:
            full_project_name += "_" + noise
        self.deprecated_config.result_folder = "results/" + time.strftime(full_project_name + "__%Y_%m_%d__%H_%M_%S", time.localtime()) + "/"
        if not os.path.exists(self.deprecated_config.result_folder): os.mkdir(self.deprecated_config.result_folder)
        if not os.path.exists(self.deprecated_config.result_folder + "images/"): os.mkdir(self.deprecated_config.result_folder + "images/")
        if not os.path.exists(self.deprecated_config.result_folder + "models/"): os.mkdir(self.deprecated_config.result_folder + "models/")
        with open(self.deprecated_config.result_folder + "/train_params.txt", "w") as file:
            content = "-----------------------" + time.strftime("Date: %Y/%m/%d %H:%M:%S",
                                                                time.localtime()) + "-----------------------\n"

            for item in self.deprecated_config.get_items():
                content += item[0] + " = " + str(item[1]) + "\n"

            print(content)
            file.write(content)
        with open(self.deprecated_config.result_folder + "/train_log.txt", "w") as file:
            content = "-----------------------" + time.strftime("Date: %Y/%m/%d %H:%M:%S",
                                                                time.localtime()) + "-----------------------\n"
            file.write(content)
        with open(self.deprecated_config.result_folder + "/val_log.txt", "w") as file:
            content = "-----------------------" + time.strftime("Date: %Y/%m/%d %H:%M:%S",
                                                                time.localtime()) + "-----------------------\n"
            file.write(content)
        
    class WeightPath:
        def __init__(self):
            self.encoder_decoder_origin = "/root/autodl-tmp/Multi-Watermarking/Code/MBRS/r1/MBRS_256_m256/models/EC_42.pth"
            self.discriminator_origin = "/root/autodl-tmp/Multi-Watermarking/Code/MBRS/r1/MBRS_256_m256/models/D_42.pth"
            # TODO: fix path
            self.encoder_decoder_multiple = "/root/autodl-tmp/Multi-Watermarking/Code/MBRS/r1/MBRS_m64_Combined([JpegMask(50),Jpeg(50),Identity()])__2025_07_07__12_31_33/models/EC_double_129.pth"
            self.discriminator_multiple = "/root/autodl-tmp/Multi-Watermarking/Code/MBRS/r1/MBRS_m64_Combined([JpegMask(50),Jpeg(50),Identity()])__2025_07_07__12_31_33/models/D_double_129.pth"