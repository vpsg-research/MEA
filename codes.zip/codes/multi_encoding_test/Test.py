import pandas as pd
import os
import random
import time
import numpy as np
import torch
import torchvision.utils
from torchvision import transforms
from torch.utils.data import Dataset
from PIL import Image
from tqdm import tqdm
from torch.utils.data import DataLoader
from skimage.metrics import peak_signal_noise_ratio, structural_similarity

def getImageOrigin(path_image, size=256):
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5]), 
        transforms.Resize((size, size), antialias=True)
    ])
    image = transform(Image.open(path_image).convert("RGB"))
    return image

class ResultAdapter:
    def __init__(self, model_name: str):
        self.tested = True
        
        # ! Change the dataset folder
        self.common_dataset_folder = "/root/autodl-tmp/dataset/wo-sub"
        self.common_result_folder = '/root/autodl-tmp/Multi-Watermarking/Code/CommonResult'
        self.model_result_folder = os.path.join(self.common_result_folder, model_name)
        
        self.folders = {
            'repository': os.path.join(self.model_result_folder, 'repository'),
            'checkpoint': os.path.join(self.model_result_folder, 'checkpoint'),
            'summary': os.path.join(self.model_result_folder, 'summary')
        }
        
        if not os.path.exists(self.folders['repository']): # This model result has not ever been saved
            self.tested = False
            for k, v in self.folders.items():
                if not os.path.exists(v): os.makedirs(v, exist_ok=True)
            for split in ['origin', 'multi']:
                for i in os.listdir(os.path.join(self.common_dataset_folder, os.getenv("TEST_MODE"))):
                    os.makedirs(os.path.join(self.folders['repository'], split, i[:-4]), exist_ok=True)
                    # For image i
                    os.makedirs(os.path.join(self.folders['repository'], split, i[:-4], 'watermarked'), exist_ok=True) # {model_name}-{encoding_num}-{i}.png
                
class MultiEnTester():
    def __init__(self, name: str, network_origin, network_double, test_loader, CustomDataset):
        assert len(test_loader) > 0, "test_loader is empty"
        
        self.name = name
        self.network_origin = network_origin
        self.network_double = network_double
        self.test_loader = test_loader
        self.save_iterations = np.random.choice(np.arange(0, len(self.test_loader)), int(len(self.test_loader)*0.3), replace=False)
        self.result = []
        self.xber_result = []
        self.CustomDataset = CustomDataset
        self.message = self.generate_message(self.test_loader.batch_size, self.network_origin.message_length)[0]
        
        self._seed_torch(42)

        # Create model result folder
        self.result_adapter = ResultAdapter(self.name)

    def make_dataloader(self, type, name_model_repository, number_encode, name_model_image):
        dataset = self.CustomDataset(os.path.join(self.result_adapter.common_result_folder, name_model_repository, 'repository', type), name_model=name_model_image, number_encode=number_encode)
        return DataLoader(dataset, batch_size=self.test_loader.batch_size, shuffle=False, num_workers=0)
        
    def calculate_bit_error_rate(self, original_message: torch.Tensor, decoded_message: torch.Tensor) -> float:
        raise NotImplementedError
    
    def generate_message(self, batch_size: int, message_length: int) -> torch.Tensor:
        raise NotImplementedError
    
    def get_psnr(self, original_image: torch.Tensor, encoded_image: torch.Tensor) -> float:
        assert original_image.shape == encoded_image.shape, "original_image and encoded_image should have the same shape"
        batch_size = original_image.shape[0]
        total_psnr = 0.0
        for k in range(batch_size):
            original_image_single_numpy = np.ascontiguousarray(original_image[k].permute(1, 2, 0).cpu().numpy())
            encoded_image_single_numpy = np.ascontiguousarray(encoded_image[k].permute(1, 2, 0).cpu().numpy())
            total_psnr += peak_signal_noise_ratio(original_image_single_numpy, encoded_image_single_numpy, data_range=1.0)
        return total_psnr / batch_size

    def get_ssim(self, original_image: torch.Tensor, encoded_image: torch.Tensor) -> float:
        assert original_image.shape == encoded_image.shape, "original_image and encoded_image should have the same shape"
        batch_size = original_image.shape[0]
        total_psnr = 0.0
        for k in range(batch_size):
            original_image_single_numpy = np.ascontiguousarray(original_image[k].permute(1, 2, 0).cpu().numpy())
            encoded_image_single_numpy = np.ascontiguousarray(encoded_image[k].permute(1, 2, 0).cpu().numpy())
            total_psnr += structural_similarity(original_image_single_numpy, encoded_image_single_numpy, data_range=1.0, channel_axis=-1, win_size=7)
        return total_psnr / batch_size
    
    def encode(self, network, image: torch.Tensor, message: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError

    def decode(self, network, image: torch.Tensor):
        raise NotImplementedError
    
    def encode_decode(self, network, image: torch.Tensor, message: torch.Tensor):
        raise NotImplementedError
        
    def test_across_model_decode_specific(self, network, number_mutiple_encoding: int, type: str):
        res = {
            'XBER': 0.0,
        }
        
        for i, (image, name, message) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with xdecoding {number_mutiple_encoding} Testing'):
            image, message = image.to(network.device), message.to(network.device)
            decoded_messages = self.decode(network, image)
            res['XBER'] += self.calculate_bit_error_rate(message, decoded_messages)
        res = {key: value / len(self.test_loader) for key, value in res.items()}
        return res
    
    def test_across_model_decode(self, double_encoding_num: int=1, gen_summary: bool=True):
        set_res = set([i[:-6] for i in os.listdir(os.path.join(self.result_adapter.common_result_folder, self.name, 'repository', 'multi', '00002', 'watermarked'))])
        if len(set_res) <= 0: return None
        for name_model in set_res:
            for i in range(1, double_encoding_num+1): # [1, 5]
                with torch.no_grad():
                    self.test_loader = self.make_dataloader('multi', self.name, i, name_model)
                    summary_double = self.test_across_model_decode_specific(self.network_double, i, "multi")
                    self.test_loader = self.make_dataloader('origin', self.name, i, name_model)
                    summary_origin = self.test_across_model_decode_specific(self.network_origin, i, "origin")
                
                summary_origin['name'] = "origin"
                summary_double['name'] = "multi"
                summary_origin['encoding_num'] = i
                summary_double['encoding_num'] = i
                summary_origin['model_name'] = name_model
                summary_double['model_name'] = name_model
                
                self.xber_result.append(summary_origin)
                self.xber_result.append(summary_double)
            if gen_summary:
                self.generate_summary(data=self.xber_result, name="xber_result", folder=self.result_adapter.folders['summary'])

    def test_across_model_encode_specific(self, network, number_mutiple_encoding: int, type: str, name_model: str):
        for i, (image, name, message) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with encoding {number_mutiple_encoding} Testing'):
            batch_size = image.shape[0]
            image = image.to(network.device)
            message = self.generate_message(batch_size, network.message_length).to(network.device)
            encoded_images, noised_images, decoded_messages = self.encode_decode(network, image, message)
            
            # Add multiple watermark
            double_encoded_images = noised_images
            for j in range(number_mutiple_encoding):
                double_message = self.generate_message(batch_size, network.message_length).to(network.device)
                double_encoded_images, _, double_decoded_messages = self.encode_decode(network, double_encoded_images, double_message)

            for idx, n in enumerate(name):
                self.general_save_image(
                    double_encoded_images[idx], 
                    os.path.join(
                        self.result_adapter.common_result_folder, 
                        name_model, 
                        'repository',
                        type, 
                        n, 
                        'watermarked'
                    ), 
                    f"{self.name}-{number_mutiple_encoding}.png"
                )
            
    def test_across_model_encode(self, double_encoding_num: int=1):
        for model in os.listdir(self.result_adapter.common_result_folder):
            # Check if repository is itself
            if model == self.name: continue
            # Check if repository has been encoded
            if [self.name in i for i in os.listdir(os.path.join(self.result_adapter.common_result_folder, model, 'repository', 'multi' ,'00002' , 'watermarked'))].count(True) > 0: continue
            for number_encode in range(1, double_encoding_num+1):
                with torch.no_grad():
                    self.test_loader = self.make_dataloader('origin', model, 1, model)
                    self.test_across_model_encode_specific(self.network_origin, number_mutiple_encoding=number_encode, type="origin", name_model=model)
                    self.test_loader = self.make_dataloader('multi', model, 1, model)
                    self.test_across_model_encode_specific(self.network_double, number_mutiple_encoding=number_encode, type="multi", name_model=model)    
    
    def test(self, double_encoding_num: int=1, gen_summary: bool=True):
        start = time.time()
        if not self.result_adapter.tested:
            print(f"> {self.name} is not tested, now start testing...")
            self.test_single_model(double_encoding_num=double_encoding_num, gen_summary=gen_summary)
        print(f"> {self.name} single model testing is DONE. Time elapsed: {time.time() - start:.2f}s")
        print("> Now start testing across model...")
        self.test_across_model_encode(double_encoding_num=double_encoding_num)
        print(f"{self.name} encode other model is DONE. Time elapsed: {time.time() - start:.2f}s")
        print("> Now start testing across model decode...")
        self.test_across_model_decode(double_encoding_num=double_encoding_num, gen_summary=gen_summary)
        print(f"> Testing {self.name} is ALL DONE. Time elapsed: {time.time() - start:.2f}s")
    
    def test_single_model(self, double_encoding_num: int=1, gen_summary: bool=True):
        print(f"> {self.__class__.__name__}: {self.name} is not tested, now start testing...")
        for i in range(1, double_encoding_num+1):
            with torch.no_grad():
                summary_double = self.test_encode_decode(self.network_double, i, "multi")
                summary_origin = self.test_encode_decode(self.network_origin, i, "origin")
            
            summary_origin['name'] = "origin"
            summary_double['name'] = "multi"
            summary_origin['encoding_num'] = i
            summary_double['encoding_num'] = i
        
            self.result.append(summary_origin)
            self.result.append(summary_double)
        if gen_summary:
            self.generate_summary(data=self.result, name="result", folder=self.result_adapter.folders['summary'])
    
    def test_encode_decode(self, network, double_encoding_num: int, type: str="origin") -> dict:
        res = {
            'BER': 0.0,
            'MBER': 0.0,
            'PSNR': 0.0,
            'SSIM': 0.0, 
            'MPSNR': 0.0,
            'MSSIM': 0.0
        }
        
        for i, (image, name, image_origin) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with encoding {double_encoding_num} Testing'):
            batch_size = image.shape[0]
            image = image.to(network.device)
            image_origin = image_origin.to(network.device)
            message = self.message.repeat(batch_size, 1).to(network.device)
            encoded_images, noised_images, decoded_messages = self.encode_decode(network, image, message)
            
            # Add multiple watermark
            double_encoded_images = noised_images
            for j in range(double_encoding_num):
                double_message = self.generate_message(batch_size, network.message_length).to(network.device)
                double_encoded_images, _, double_decoded_messages = self.encode_decode(network, double_encoded_images, double_message)

            res['PSNR'] += self.get_psnr(image, encoded_images)
            res['SSIM'] += self.get_ssim(image, encoded_images)
            res['MPSNR'] += self.get_psnr(image, double_encoded_images)
            res['MSSIM'] += self.get_ssim(image, double_encoded_images)
            res['BER'] += self.calculate_bit_error_rate(message, decoded_messages)
            res['MBER'] += self.calculate_bit_error_rate(message, double_decoded_messages)
            self.save_image(image_origin, encoded_images, double_encoded_images, name, double_encoding_num+1, os.path.join(self.result_adapter.folders['repository'], type))
            self.save_message(message, name, os.path.join(self.result_adapter.folders['repository'], type))
        res = {key: value / len(self.test_loader) for key, value in res.items()}
        return res
    
    def _seed_torch(self, seed=42):
        seed = int(seed)
        random.seed(seed)
        os.environ['PYTHONHASHSEED'] = str(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.enabled = True
    
    def generate_summary(self, data: dict, name: str, to_markdown: bool=True, to_csv: bool=True, folder: str="fine_tuning"):  
        summary = pd.DataFrame(data)
        if not os.path.exists(folder): os.makedirs(folder)
        if to_markdown:
            summary.to_markdown(f"{folder}/{name}.md", index=False)
            print(f"> {self.__class__.__name__}: Summary saved to {folder}/{name}.md")
        if to_csv:
            summary.to_csv(f"{folder}/{name}.csv", index=False)
            print(f"> {self.__class__.__name__}: Summary saved to {folder}/{name}.csv")
    
    def tensor_to_image(self, image):
        image = image[:, :, :].cpu()
        image = (image + 1) / 2
        return image
    
    def save_image(self, original_image: torch.Tensor, watermarked_image: torch.Tensor, multi_watermarked_image: torch.Tensor, name, encoding_num: int, repository: str=None):
        # Save batch
        for idx, n in enumerate(name):
            self.general_save_image(original_image[idx], os.path.join(repository, n), 'original.png')
            self.general_save_image(watermarked_image[idx], os.path.join(repository, n, 'watermarked'), f'{self.name}-1.png')
            self.general_save_image(multi_watermarked_image[idx], os.path.join(repository, n, 'watermarked'), f'{self.name}-{encoding_num}.png')

    def general_save_image(self, image: torch.Tensor, folder: str, name: str):
        image = self.tensor_to_image(image)
        torchvision.utils.save_image(tensor=image, fp=os.path.join(folder, name), format='png', nrow=image.shape[0], normalize=False)
    
    def save_message(self, message: torch.Tensor, name, repositoy: str=None):
        for idx, n in enumerate(name):
            message_path = os.path.join(repositoy, n, 'message.npy')
            if not os.path.exists(message_path): np.save(message_path, message[idx].detach().cpu().numpy())
        
    def save_checkpoint(self, model, module_name: str):
        checkpoint_path = os.path.join(self.result_adapter.folders['checkpoint'], module_name)
        torch.save(model.state_dict(), checkpoint_path)