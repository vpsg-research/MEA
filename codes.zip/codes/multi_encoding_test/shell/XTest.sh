rm -rf /root/autodl-tmp/Multi-Watermarking/Code/CommonResult/*
export TEST_MODE=test_tiny
# ! Generate Single Model Test
. /root/autodl-tmp/Multi-Watermarking/Code/MBRS/fine_tuning/shell/test.sh && \
. /root/autodl-tmp/Multi-Watermarking/Code/SepMark/fine_tuning/shell/test.sh && \
. /root/autodl-tmp/Multi-Watermarking/Code/LampMark/fine_tuning/shell/test.sh && \
. /root/autodl-tmp/Multi-Watermarking/Code/HiDDeN/fine_tuning/shell/test.sh && \
. /root/autodl-tmp/Multi-Watermarking/Code/WaveGuard/fine_tuning/shell/test.sh && \
. /root/autodl-tmp/Multi-Watermarking/Code/EditGuard/code/fine_tuning/shell/test.sh && \
# ! Generate X Model Test
. /root/autodl-tmp/Multi-Watermarking/Code/MBRS/fine_tuning/shell/test.sh && \
. /root/autodl-tmp/Multi-Watermarking/Code/SepMark/fine_tuning/shell/test.sh && \
. /root/autodl-tmp/Multi-Watermarking/Code/LampMark/fine_tuning/shell/test.sh && \
. /root/autodl-tmp/Multi-Watermarking/Code/HiDDeN/fine_tuning/shell/test.sh && \
. /root/autodl-tmp/Multi-Watermarking/Code/WaveGuard/fine_tuning/shell/test.sh && \
. /root/autodl-tmp/Multi-Watermarking/Code/EditGuard/code/fine_tuning/shell/test.sh