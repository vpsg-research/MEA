conda activate hidden
cd /root/autodl-tmp/Multi-Watermarking/Code/HiDDeN

python -u fine_tuning/fine_tuning.py continue \
-f "runs/lastest" \
-d /root/autodl-tmp/dataset/w-sub \
-e 300