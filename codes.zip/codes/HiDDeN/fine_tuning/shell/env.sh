cd /root/autodl-tmp/Multi-Watermarking/Code/HiDDeN && \
conda activate base && \
conda env remove -n hidden -y && \
mamba create -n hidden python=3.8 -y && \
conda activate hidden && \
pip install uv && \
mamba install pytorch==2.0.0 torchvision==0.15.0 torchaudio==2.0.0 pytorch-cuda=11.8 -c pytorch -c nvidia -y && \
mamba install pandas tabulate tensorboardX tensorboard Pillow -y && \
uv pip install Pillow==6.2.2 torchmetrics tqdm debugpy