conda activate hidden
cd /root/autodl-tmp/Multi-Watermarking/Code/HiDDeN

python -u fine_tuning/test.py \
--options-file "runs/train-test-1 2025.07.09--12-49-43/options-and-config.pickle" \
--checkpoint-file "runs/train-test-1 2025.07.09--12-49-43/checkpoints/train-test-1--epoch-200.pyt" \
--test-folder "/root/autodl-tmp/dataset/w-sub/$TEST_MODE" \
--test-model "runs/train-test-1-backup/checkpoints/train-test-1--epoch-100.pyt"