conda activate hidden
cd /root/autodl-tmp/projects/HiDDeN
tensorboard --logdir="runs/train-test-1 2025.04.22--15-03-07/tb-logs"