7z a HiDDeN-weight.7z \
"runs/train-test-1 2025.07.09--12-49-43/checkpoints/train-test-1--epoch-200.pyt" \
"runs/train-test-1-backup/checkpoints/train-test-1--epoch-100.pyt" \
"runs/train-test-1 2025.07.09--12-49-43/options-and-config.pickle" && \
rclone copy HiDDeN-weight.7z gdrive:ModelWeights -P && \
rm HiDDeN-weight.7z