conda activate hidden
cd /root/autodl-tmp/Multi-Watermarking/Code/HiDDeN

python -u main.py new -d /root/autodl-tmp/dataset/w-sub -e 100 -b 8 -s 256 --name train-test-1 --tensorboard