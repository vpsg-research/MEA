import os
import sys
sys.path.append(os.getcwd())
from random import randint

from model.hidden import *

class FineTuningNetwork(Hidden):
    def __init__(self, configuration, device, noiser, tb_logger):
        super().__init__(configuration, device, noiser, tb_logger)
        self.double_message_weight = 1
        self.g_loss_double_weight = 1
        # ! For MultiEnTester
        self.message_length = configuration.message_length
        
    def train_on_batch(self, batch: list):
        """
        Trains the network on a single batch consisting of images and messages
        :param batch: batch of training data, in the form [images, messages]
        :return: dictionary of error metrics from Encoder, Decoder, and Discriminator on the current batch
        """
        self.encoder_decoder.train()
        self.discriminator.train()
        
        images, messages = batch
        batch_size = images.shape[0]
        
        with torch.enable_grad():
            # ======================= Train the discriminator ======================= #
            self.optimizer_discrim.zero_grad()
            # train on cover
            d_target_label_cover = torch.full((batch_size, 1), self.cover_label, device=self.device, dtype=torch.float32)
            d_target_label_encoded = torch.full((batch_size, 1), self.encoded_label, device=self.device, dtype=torch.float32)
            g_target_label_encoded = torch.full((batch_size, 1), self.cover_label, device=self.device, dtype=torch.float32)

            d_on_cover = self.discriminator(images)
            d_loss_on_cover = self.bce_with_logits_loss(d_on_cover, d_target_label_cover)
            d_loss_on_cover.backward()

            # train on fake
            encoded_images, noised_images, decoded_messages = self.encoder_decoder(images, messages)
            d_on_encoded = self.discriminator(encoded_images.detach())
            d_loss_on_encoded = self.bce_with_logits_loss(d_on_encoded, d_target_label_encoded)

            d_loss_on_encoded.backward()
            self.optimizer_discrim.step()

            # ================ Train the generator (encoder-decoder) ================ #
            self.optimizer_enc_dec.zero_grad()
            # target label for encoded images should be 'cover', because we want to fool the discriminator
            d_on_encoded_for_enc = self.discriminator(encoded_images)
            g_loss_adv = self.bce_with_logits_loss(d_on_encoded_for_enc, g_target_label_encoded)

            if self.vgg_loss == None:
                g_loss_enc = self.mse_loss(encoded_images, images)
            else:
                vgg_on_cov = self.vgg_loss(images)
                vgg_on_enc = self.vgg_loss(encoded_images)
                g_loss_enc = self.mse_loss(vgg_on_cov, vgg_on_enc)

            g_loss_dec = self.mse_loss(decoded_messages, messages)
            
            # ========================= Double watermarking ========================= #
            double_encoded_images = encoded_images.clone()
            for i in range(1, randint(2, 3)):
                double_message = torch.Tensor(np.random.choice([0, 1], (images.shape[0], self.config.message_length))).to(self.device)
                double_encoded_images, _, double_decoded_messages = self.encoder_decoder(double_encoded_images, double_message)
            
            g_loss_double = (
                # self.destruction_criterion(double_encoded_images.detach(), encoded_images) * self.destructive_weight + # Deconstruct image
                self.mse_loss(double_decoded_messages, messages) * self.double_message_weight
                # self.mse_loss(double_encoded_images.detach(), torch.zeros_like(encoded_images)) * self.destructive_weight
                # self.mse_loss(double_encoded_images.detach(), images) * self.destructive_weight
            )
            
            g_loss = (
                self.config.adversarial_loss * g_loss_adv + 
                self.config.encoder_loss * g_loss_enc + 
                self.config.decoder_loss * g_loss_dec + 
                g_loss_double * self.g_loss_double_weight
            )

            g_loss.backward()
            self.optimizer_enc_dec.step()

        decoded_rounded = decoded_messages.detach().cpu().numpy().round().clip(0, 1)
        bitwise_avg_err = np.sum(np.abs(decoded_rounded - messages.detach().cpu().numpy())) / (batch_size * messages.shape[1])
        # ========================= Double watermarking ========================= #
        double_decoded_rounded = double_decoded_messages.detach().cpu().numpy().round().clip(0, 1)
        double_bitwise_avg_err = np.sum(np.abs(double_decoded_rounded - messages.detach().cpu().numpy())) / (batch_size * messages.shape[1])

        losses = {
            'loss           ': g_loss.item(),
            'encoder_mse    ': g_loss_enc.item(),
            'dec_mse        ': g_loss_dec.item(),
            'bitwise-error  ': bitwise_avg_err,
            'adversarial_bce': g_loss_adv.item(),
            'discr_cover_bce': d_loss_on_cover.item(),
            'discr_encod_bce': d_loss_on_encoded.item(), 
            'd_bitwise-error': double_bitwise_avg_err,
            'g_loss_double  ': g_loss_double.item()
        }
        return losses, (encoded_images, noised_images, decoded_messages)

    def validate_on_batch(self, batch: list):
        """
        Runs validation on a single batch of data consisting of images and messages
        :param batch: batch of validation data, in form [images, messages]
        :return: dictionary of error metrics from Encoder, Decoder, and Discriminator on the current batch
        """
        # if TensorboardX logging is enabled, save some of the tensors.
        if self.tb_logger is not None:
            encoder_final = self.encoder_decoder.encoder._modules['final_layer']
            self.tb_logger.add_tensor('weights/encoder_out', encoder_final.weight)
            decoder_final = self.encoder_decoder.decoder._modules['linear']
            self.tb_logger.add_tensor('weights/decoder_out', decoder_final.weight)
            discrim_final = self.discriminator._modules['linear']
            self.tb_logger.add_tensor('weights/discrim_out', discrim_final.weight)

        images, messages = batch

        batch_size = images.shape[0]
        
        # Statics is not correctly updated in train process, and i do not have better solution
        # for m in self.encoder_decoder.modules():
        #     if isinstance(m, torch.nn.BatchNorm2d):
        #         m.track_running_stats, m.running_mean, m.running_var = False, None, None
        # self.encoder_decoder.eval()
        # self.discriminator.eval()
        
        with torch.no_grad():
            d_target_label_cover = torch.full((batch_size, 1), self.cover_label, device=self.device, dtype=torch.float32)
            d_target_label_encoded = torch.full((batch_size, 1), self.encoded_label, device=self.device, dtype=torch.float32)
            g_target_label_encoded = torch.full((batch_size, 1), self.cover_label, device=self.device, dtype=torch.float32)

            d_on_cover = self.discriminator(images)
            d_loss_on_cover = self.bce_with_logits_loss(d_on_cover, d_target_label_cover)

            encoded_images, noised_images, decoded_messages = self.encoder_decoder(images, messages)

            d_on_encoded = self.discriminator(encoded_images)
            d_loss_on_encoded = self.bce_with_logits_loss(d_on_encoded, d_target_label_encoded)

            d_on_encoded_for_enc = self.discriminator(encoded_images)
            g_loss_adv = self.bce_with_logits_loss(d_on_encoded_for_enc, g_target_label_encoded)

            if self.vgg_loss is None:
                g_loss_enc = self.mse_loss(encoded_images, images)
            else:
                vgg_on_cov = self.vgg_loss(images)
                vgg_on_enc = self.vgg_loss(encoded_images)
                g_loss_enc = self.mse_loss(vgg_on_cov, vgg_on_enc)

            g_loss_dec = self.mse_loss(decoded_messages, messages)
            # ========================= Double watermarking ========================= #
            double_message = torch.Tensor(np.random.choice([0, 1], (images.shape[0], self.config.message_length))).to(self.device)
            double_encoded_images, double_noised_images, double_decoded_messages = self.encoder_decoder(noised_images, double_message)
            g_loss_double = (
                # self.destruction_criterion(double_encoded_images.detach(), encoded_images) * self.destructive_weight + # Deconstruct image
                self.mse_loss(double_decoded_messages, messages) * self.double_message_weight
                # self.mse_loss(double_encoded_images.detach(), torch.zeros_like(encoded_images)) * self.destructive_weight
                # self.mse_loss(double_encoded_images.detach(), images) * self.destructive_weight
            )
            
            g_loss = (
                self.config.adversarial_loss * g_loss_adv + 
                self.config.encoder_loss * g_loss_enc + 
                self.config.decoder_loss * g_loss_dec + 
                g_loss_double * self.g_loss_double_weight
            )

        decoded_rounded = decoded_messages.detach().cpu().numpy().round().clip(0, 1)
        bitwise_avg_err = np.sum(np.abs(decoded_rounded - messages.detach().cpu().numpy())) / (
                batch_size * messages.shape[1])
        # ========================= Double watermarking ========================= #
        double_decoded_rounded = double_decoded_messages.detach().cpu().numpy().round().clip(0, 1)
        double_bitwise_avg_err = np.sum(np.abs(double_decoded_rounded - messages.detach().cpu().numpy())) / (batch_size * messages.shape[1])

        losses = {
            'loss           ': g_loss.item(),
            'encoder_mse    ': g_loss_enc.item(),
            'dec_mse        ': g_loss_dec.item(),
            'bitwise-error  ': bitwise_avg_err,
            'adversarial_bce': g_loss_adv.item(),
            'discr_cover_bce': d_loss_on_cover.item(),
            'discr_encod_bce': d_loss_on_encoded.item(), 
            'd_bitwise-error': double_bitwise_avg_err,
            'g_loss_double  ': g_loss_double.item()
        }
        return losses, (encoded_images, noised_images, decoded_messages)
