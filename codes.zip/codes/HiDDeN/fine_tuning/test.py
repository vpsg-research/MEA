import argparse
import torch
from torch.utils.data import Dataset
from torchvision import datasets, transforms
import numpy as np
from torchmetrics.image import PeakSignalNoiseRatio, StructuralSimilarityIndexMeasure
import os
import sys
from tqdm import tqdm
sys.path.append(os.getcwd())
sys.path.append(os.path.dirname(os.getcwd()))

import utils
from Network import *
from noise_layers.noiser import Noiser
from options import HiDDenConfiguration
from multi_encoding_test.Test import MultiEnTester, getImageOrigin

class Tester(MultiEnTester):
    def __init__(self, name, network_origin, network_double, test_loader, CustomDataset):
        super().__init__(name, network_origin, network_double, test_loader, CustomDataset)
        self.psnr = PeakSignalNoiseRatio(data_range=2.0).to(self.network_origin.device)
        self.ssim = StructuralSimilarityIndexMeasure(data_range=2.0).to(self.network_origin.device)
        self.message = self.generate_message(self.test_loader.batch_size, self.network_origin.message_length)
        
    def calculate_bit_error_rate(self, original_message: torch.Tensor, decoded_message: torch.Tensor) -> float:
        decoded_rounded = decoded_message.detach().cpu().numpy().round().clip(0, 1)
        bitwise_avg_err = np.sum(np.abs(decoded_rounded - original_message.detach().cpu().numpy())) / (decoded_message.shape[0] * decoded_message.shape[1])
        return bitwise_avg_err
    
    def generate_message(self, batch_size: int, message_length: int) -> torch.Tensor:
        return torch.Tensor(np.random.choice([0, 1], (batch_size, message_length)))
    
    def get_psnr(self, original_image: torch.Tensor, encoded_image: torch.Tensor) -> float:
        return self.psnr(original_image, encoded_image).item()

    def get_ssim(self, original_image: torch.Tensor, encoded_image: torch.Tensor) -> float:
        return self.ssim(original_image, encoded_image).item()
    
    def encode(self, network, image: torch.Tensor, message: torch.Tensor) -> torch.Tensor:
        return network.encoder_decoder.encoder(image, message)

    def decode(self, network, image: torch.Tensor):
        return network.encoder_decoder.decoder(image)
    
    def encode_decode(self, network, image: torch.Tensor, message: torch.Tensor):
        encoded_images, noised_images, decoded_messages = network.encoder_decoder(image, message)
        return noised_images, noised_images, decoded_messages
    
    def test_encode_decode(self, network, double_encoding_num: int, type: str="origin") -> dict:
        res = {
            'BER': 0.0,
            'MBER': 0.0,
            'PSNR': 0.0,
            'SSIM': 0.0, 
            'MPSNR': 0.0,
            'MSSIM': 0.0
        }
        
        for i, (image, name, image_origin) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with encoding {double_encoding_num} Testing'):
            batch_size = image.shape[0]
            image = image.to(network.device)
            image_origin = image_origin.to(network.device)
            message = self.message[:image.shape[0]].to(network.device)
            encoded_images, noised_images, decoded_messages = self.encode_decode(network, image, message)
            
            # Add multiple watermark
            double_encoded_images = noised_images
            for j in range(double_encoding_num):
                double_message = self.generate_message(batch_size, network.message_length).to(network.device)
                double_encoded_images, _, double_decoded_messages = self.encode_decode(network, double_encoded_images, double_message)

            res['PSNR'] += self.get_psnr(image, encoded_images)
            res['SSIM'] += self.get_ssim(image, encoded_images)
            res['MPSNR'] += self.get_psnr(image, double_encoded_images)
            res['MSSIM'] += self.get_ssim(image, double_encoded_images)
            res['BER'] += self.calculate_bit_error_rate(message, decoded_messages)
            res['MBER'] += self.calculate_bit_error_rate(message, double_decoded_messages)
            self.save_image(image_origin, encoded_images, double_encoded_images, name, double_encoding_num+1, os.path.join(self.result_adapter.folders['repository'], type))
            self.save_message(message, name, os.path.join(self.result_adapter.folders['repository'], type))
        res = {key: value / len(self.test_loader) for key, value in res.items()}
        return res
    
def get_test_loader(hidden_config: HiDDenConfiguration):
    data_transforms = transforms.Compose([
        transforms.CenterCrop((hidden_config.H, hidden_config.W)),
        transforms.ToTensor(),
        transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
    ])

    test_images = TestDataset(args.test_folder, data_transforms)
    test_loader = torch.utils.data.DataLoader(test_images, batch_size=args.batch_size, shuffle=False, num_workers=0)

    return test_loader

class TestDataset(datasets.ImageFolder):
    def __init__(self, root, transform=None, target_transform=None):
        super().__init__(root, transform, target_transform)
    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (sample, target) where target is class_index of the target class.
        """
        path, target = self.samples[index]
        sample = self.loader(path)
        if self.transform is not None:
            sample = self.transform(sample)
        if self.target_transform is not None:
            target = self.target_transform(target)

        return sample, os.path.basename(path)[:-4], sample

class RepoModelDataset(datasets.ImageFolder):
    # def __init__(self, dataset_path, name_model:str=None, number_encode = 1):
    def __init__(self, root, transform=None, target_transform=None, name_model:str=None, number_encode = 1):
        super().__init__(root, transform, target_transform)
        self.transform = transforms.Compose([
            transforms.RandomCrop((hidden_config.H, hidden_config.W), pad_if_needed=True),
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
        ])
        dataset_path = root
        self.dataset_path = dataset_path
        self.image_filename_list = os.listdir(dataset_path)
        self.number_encode = number_encode
        self.name_model = name_model
        
    def __len__(self):
        return len(self.image_filename_list)
    
    def __getitem__(self, index):
        filename = self.image_filename_list[index]
        image = os.path.join(self.dataset_path, filename, "watermarked", f"{self.name_model}-{self.number_encode}.png")
        message = torch.from_numpy(np.load(os.path.join(self.dataset_path, filename, "message.npy")))
        
        return self.transform(self.loader(image)), filename, message

if __name__ == '__main__':
    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
    parser = argparse.ArgumentParser(description='Test trained models')
    parser.add_argument('--options-file', '-o', default='options-and-config.pickle', type=str, help='The file where the simulation options are stored.')
    parser.add_argument('--checkpoint-file', '-c', required=True, type=str, help='Model checkpoint file')
    parser.add_argument('--test-folder', '-t', default='dataset/test', type=str, help='The folder where the test images are stored.')
    parser.add_argument('--batch-size', '-b', default=12, type=int, help='The batch size.')
    parser.add_argument('--test-model', required=True, type=str, help='The folder where the test model is stored.')
    
    args = parser.parse_args()
    
    # ============================ network_double =========================== #
    train_options, hidden_config, noise_config = utils.load_options(args.options_file)
    train_options.batch_size = 8
    noiser = Noiser(noise_config, device)
    checkpoint = torch.load(args.checkpoint_file)
    network_double = FineTuningNetwork(hidden_config, device, noiser, None)
    utils.model_from_checkpoint(network_double, checkpoint)

    # ============================ network_origin =========================== #
    train_options, hidden_config, noise_config = utils.load_options(f"{os.path.dirname(os.path.dirname(args.test_model))}/options-and-config.pickle")
    train_options.batch_size = 8
    train_options.device = "cuda"
    noiser = Noiser(noise_config, device)
    checkpoint = torch.load(args.test_model)
    network_origin = FineTuningNetwork(hidden_config, device, noiser, None)
    utils.model_from_checkpoint(network_origin, checkpoint)
    tester = Tester("HiDDeN", network_origin, network_double, get_test_loader(hidden_config), RepoModelDataset)
    tester.test(5)
