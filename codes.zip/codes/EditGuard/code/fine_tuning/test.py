import argparse
import torch
from torchvision import transforms
import torchvision
import torch.nn as nn
import numpy as np
from tqdm import tqdm
from PIL import Image
import os
from fine_tuning import *
import os.path as osp
import sys
sys.path.append(os.getcwd())
sys.path.append(os.path.dirname(os.path.dirname(os.getcwd())))

from models.modules.common import DWT,IWT
from multi_encoding_test.Test import MultiEnTester, getImageOrigin
from Network import FineTuningNetwork
import options.options as option
from data.coco_test_dataset import imageTestDataset
import data.util as util
import utils.util as util_
from data.coco_dataset import CoCoDataset
    
class Test(MultiEnTester):
    def __init__(self, name, network_origin, network_double, test_loader, CustomDataset):
        super().__init__(name, network_origin, network_double, test_loader, CustomDataset)
    
    def calculate_bit_error_rate(self, original_message: torch.Tensor, decoded_message: torch.Tensor) -> float:
        return ((torch.sign(original_message) != torch.sign(decoded_message)).sum() / decoded_message.numel()).item()
    
    def get_psnr(self, original_image: torch.Tensor, encoded_image: torch.Tensor) -> float:
        assert original_image.shape == encoded_image.shape, "original_image and encoded_image should have the same shape"
        original_image = torch.nn.functional.interpolate(original_image, size=(256, 256), mode='nearest', align_corners=None)
        encoded_image = torch.nn.functional.interpolate(encoded_image, size=(256, 256), mode='nearest', align_corners=None)
        gt_img = util_.tensor2img(original_image) / 255.
        sr_img = util_.tensor2img(encoded_image) / 255.
        psnr = util_.calculate_psnr(sr_img * 255, gt_img * 255)
        return psnr
    
    def generate_message(self, batch_size: int, message_length: int) -> torch.Tensor:
        return torch.Tensor(np.random.choice([-0.5, 0.5], (batch_size, message_length)))
        
    def encode(self, network, image: torch.Tensor, message: torch.Tensor, secret: torch.Tensor) -> torch.Tensor:
        out_y, image_encode = network.netG(x=dwt(image), x_h=dwt(secret), message=message)
        return image_encode

    def decode(self, network, image: torch.Tensor, shape_message):
        all_zero = torch.zeros(shape_message).to(network.device)
        message = network.netG(x=image, message=all_zero, rev=True)
        return message
    
    def encode_decode(self, network, image: torch.Tensor, message: torch.Tensor, secret):
        image_encode = self.encode(network, image, message, secret)
        message_decode = self.decode(network, image_encode, message.shape)
        return image_encode, image_encode, message_decode
    
    def test_encode_decode(self, network, double_encoding_num: int, type: str="origin") -> dict:
        network.netG.eval()
        res = {
            'BER': 0.0,
            'MBER': 0.0,
            'PSNR': 0.0,
            'SSIM': 0.0, 
            'MPSNR': 0.0,
            'MSSIM': 0.0
        }
        for i, (image, name, image_origin, ref_L) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with encoding {double_encoding_num} Testing'):
            image, image_origin = image.to(network.device), image_origin.to(network.device)
            
            b, n, t, c, h, w = ref_L.shape
            batch_size = b
            center = t // 2
            intval = network.gop // 2
            secret = ref_L[:, :, center - intval:center + intval + 1]
            image = image[:, center - intval:center + intval + 1].reshape(b, -1, h, w)

            message = self.message.repeat(batch_size, 1).to(network.device)
            encoded_images, noised_images, decoded_messages = self.encode_decode(network, image, message, secret[:,0].reshape(b, -1, h, w))
            
            # Add multiple watermark
            double_encoded_images = noised_images
            for j in range(double_encoding_num):
                double_message = self.generate_message(batch_size, network.message_length).to(network.device)
                double_encoded_images, _, double_decoded_messages = self.encode_decode(network, double_encoded_images, double_message, secret[:,0].reshape(b, -1, h, w))

            res['PSNR'] += self.get_psnr(image, encoded_images)
            res['SSIM'] += self.get_ssim(image, encoded_images)
            res['MPSNR'] += self.get_psnr(image, double_encoded_images)
            res['MSSIM'] += self.get_ssim(image, double_encoded_images)
            res['BER'] += self.calculate_bit_error_rate(message, decoded_messages)
            res['MBER'] += self.calculate_bit_error_rate(message, double_decoded_messages)
            # print(message, double_decoded_messages)
            
            trans = transforms.Resize((256, 256))
            
            self.save_image(
                image_origin, 
                trans(encoded_images), 
                trans(double_encoded_images), 
                name, 
                double_encoding_num+1, 
                os.path.join(self.result_adapter.folders['repository'], type)
            )
            self.save_message(message, name, os.path.join(self.result_adapter.folders['repository'], type))
                
        res = {key: value / len(self.test_loader) for key, value in res.items()}
        return res
    
    def save_image(self, original_image: torch.Tensor, watermarked_image: torch.Tensor, multi_watermarked_image: torch.Tensor, name, encoding_num: int, repository: str=None):
        # Save batch
        for idx, n in enumerate(name):
            self.general_save_image(original_image[idx], os.path.join(repository, n), 'original.png')
            torchvision.utils.save_image(tensor=watermarked_image[idx], fp=os.path.join(os.path.join(repository, n, 'watermarked'), f'{self.name}-1.png'), format='png', nrow=watermarked_image[idx].shape[0], normalize=False)
            torchvision.utils.save_image(tensor=multi_watermarked_image[idx], fp=os.path.join(os.path.join(repository, n, 'watermarked'), f'{self.name}-{encoding_num}.png'), format='png', nrow=multi_watermarked_image[idx].shape[0], normalize=False)
    
    def test_across_model_encode_specific(self, network, number_mutiple_encoding: int, type: str, name_model: str):
        for i, (image, name, message, ref_L) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with encoding {number_mutiple_encoding} Testing'):
            image = image.to(network.device)
            
            b, n, t, c, h, w = ref_L.shape
            batch_size = b
            center = t // 2
            intval = network.gop // 2
            secret = ref_L[:, :, center - intval:center + intval + 1]
            image = image[:, center - intval:center + intval + 1].reshape(b, -1, h, w)

            message = self.generate_message(batch_size, network.message_length).to(network.device)
            encoded_images, noised_images, decoded_messages = self.encode_decode(network, image, message, secret[:,0].reshape(b, -1, h, w))
            
            # Add multiple watermark
            double_encoded_images = noised_images
            for j in range(number_mutiple_encoding):
                double_message = self.generate_message(batch_size, network.message_length).to(network.device)
                double_encoded_images, _, double_decoded_messages = self.encode_decode(network, double_encoded_images, double_message, secret[:,0].reshape(b, -1, h, w))
            
            trans = transforms.Resize((256, 256))
            for idx, n in enumerate(name):
                torchvision.utils.save_image(
                    tensor=trans(double_encoded_images[idx]), 
                    fp=os.path.join(
                        self.result_adapter.common_result_folder, 
                        name_model, 
                        'repository',
                        type, 
                        n, 
                        'watermarked', 
                        f"{self.name}-{number_mutiple_encoding}.png"
                    ), 
                    format='png', 
                    nrow=double_encoded_images[idx].shape[0], 
                    normalize=False
                )

    def test_across_model_decode_specific(self, network, number_mutiple_encoding: int, type: str):
        res = {
            'XBER': 0.0,
        }
        
        for i, (image, name, message, ref_L) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with xdecoding {number_mutiple_encoding} Testing'):
            image, message = image.to(network.device), message.to(network.device)
            
            b, n, t, c, h, w = ref_L.shape
            center = t // 2
            intval = network.gop // 2
            image = image[:, center - intval:center + intval + 1].reshape(b, -1, h, w)
            
            decoded_messages = self.decode(network, image, message.shape)
            # print(decoded_messages, message)
            res['XBER'] += 1-self.calculate_bit_error_rate(message, decoded_messages)
            
        res = {key: value / len(self.test_loader) for key, value in res.items()}
        return res

class TestDataset(CoCoDataset):
    def __getitem__(self, index):
        GT_size = self.opt['GT_size']
        image_name = self.list_image[index]
        path_frame = os.path.join(self.data_path, image_name)
        img_GT = util.read_img(None, path_frame)
        index_h = random.randint(0, len(self.list_image) - 1)

        # random crop
        H, W, C = img_GT.shape
        rnd_h = random.randint(0, max(0, H - GT_size))
        rnd_w = random.randint(0, max(0, W - GT_size))
        img_frames = img_GT[rnd_h:rnd_h + GT_size, rnd_w:rnd_w + GT_size, :]
        # BGR to RGB, HWC to CHW, numpy to tensor
        img_frames = img_frames[:, :, [2, 1, 0]]
        img_frames = torch.from_numpy(np.ascontiguousarray(np.transpose(img_frames, (2, 0, 1)))).float().unsqueeze(0)

        # process h_list
        if index_h % 100 == 0:
            path_frame_h = config.secret_image_path
        else:
            image_name_h = self.list_image[index_h]
            path_frame_h = os.path.join(self.data_path, image_name_h)
        
        frame_h = util.read_img(None, path_frame_h)
        H1, W1, C1 = frame_h.shape
        rnd_h = random.randint(0, max(0, H1 - GT_size))
        rnd_w = random.randint(0, max(0, W1 - GT_size))
        img_frames_h = frame_h[rnd_h:rnd_h + GT_size, rnd_w:rnd_w + GT_size, :]
        img_frames_h = img_frames_h[:, :, [2, 1, 0]]
        img_frames_h = torch.from_numpy(np.ascontiguousarray(np.transpose(img_frames_h, (2, 0, 1)))).float().unsqueeze(0)

        img_frames_h = torch.nn.functional.interpolate(img_frames_h, size=(512, 512), mode='nearest', align_corners=None).unsqueeze(0)
        img_frames = torch.nn.functional.interpolate(img_frames, size=(512, 512), mode='nearest', align_corners=None)

        return (
            img_frames, 
            image_name[:-4], 
            getImageOrigin(os.path.join(self.data_path, image_name)),
            img_frames_h, 
        )

class RepoModelDataset(CoCoDataset):
    def __init__(self, dataset_path, name_model, number_encode):
        opt['datasets']['train']['data_path'] = dataset_path
        super().__init__(opt['datasets']['train'])
        self.name_model = name_model
        self.number_encode = number_encode
    
    def __getitem__(self, index):
        GT_size = self.opt['GT_size']
        image_name = self.list_image[index]
        # path_frame = os.path.join(self.data_path, image_name)
        path_frame = os.path.join(self.data_path, image_name, "watermarked", f"{self.name_model}-{self.number_encode}.png")
        img_GT = util.read_img(None, path_frame)
        index_h = random.randint(0, len(self.list_image) - 1)

        # random crop
        H, W, C = img_GT.shape
        rnd_h = random.randint(0, max(0, H - GT_size))
        rnd_w = random.randint(0, max(0, W - GT_size))
        img_frames = img_GT[rnd_h:rnd_h + GT_size, rnd_w:rnd_w + GT_size, :]
        # BGR to RGB, HWC to CHW, numpy to tensor
        img_frames = img_frames[:, :, [2, 1, 0]]
        img_frames = torch.from_numpy(np.ascontiguousarray(np.transpose(img_frames, (2, 0, 1)))).float().unsqueeze(0)

        # process h_list
        if index_h % 100 == 0:
            path_frame_h = config.secret_image_path
        else:
            image_name_h = self.list_image[index_h]
            # path_frame_h = os.path.join(self.data_path, image_name_h)
            path_frame_h = os.path.join(self.data_path, image_name_h, "watermarked", f"{self.name_model}-{self.number_encode}.png")
        
        frame_h = util.read_img(None, path_frame_h)
        H1, W1, C1 = frame_h.shape
        rnd_h = random.randint(0, max(0, H1 - GT_size))
        rnd_w = random.randint(0, max(0, W1 - GT_size))
        img_frames_h = frame_h[rnd_h:rnd_h + GT_size, rnd_w:rnd_w + GT_size, :]
        img_frames_h = img_frames_h[:, :, [2, 1, 0]]
        img_frames_h = torch.from_numpy(np.ascontiguousarray(np.transpose(img_frames_h, (2, 0, 1)))).float().unsqueeze(0)

        img_frames_h = torch.nn.functional.interpolate(img_frames_h, size=(512, 512), mode='nearest', align_corners=None).unsqueeze(0)
        img_frames = torch.nn.functional.interpolate(img_frames, size=(512, 512), mode='nearest', align_corners=None)

        return (
            img_frames, 
            image_name, 
            torch.from_numpy(np.load(os.path.join(self.data_path, image_name, "message.npy"))), 
            img_frames_h, 
        )

if __name__ == '__main__':
    
    dwt=DWT()
    iwt=IWT()
    
    from EditGuardConfig import EditGuardConfig
    config = EditGuardConfig()
    opt = config.yaml_config
    
    test_dataset = TestDataset(opt['datasets']['train'])
    test_dataset.data_path = "/root/autodl-tmp/dataset/wo-sub/"+os.getenv("TEST_MODE")
    test_dataloader = torch.utils.data.DataLoader(test_dataset, batch_size=config.batch_size, shuffle=False, num_workers=config.num_workers)
    assert test_dataloader is not None and len(test_dataloader) > 0, "Test dataset is empty."
    
    origin = FineTuningNetwork(opt, int(0.3*len(test_dataloader)), 5*len(test_dataloader))
    double = FineTuningNetwork(opt, int(0.3*len(test_dataloader)), 5*len(test_dataloader))
    
    origin.load_network(config.test_config.weight_network_origin_path, origin.netG, origin.opt['path']['strict_load'])
    double.load_network(config.test_config.weight_network_multiple_path, double.netG, double.opt['path']['strict_load'])
    
    tester = Test("EditGuard", origin, double, test_dataloader, RepoModelDataset)
    
    tester.test(double_encoding_num=5)
    