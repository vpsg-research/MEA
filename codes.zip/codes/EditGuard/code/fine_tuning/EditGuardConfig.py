import options.options as option
import os

class EditGuardConfig:
    class TestConfig:
        def __init__(self):
            self.weight_network_origin_path = '/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/checkpoints/clean.pth'
            self.weight_network_multiple_path = '/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/experiments/train_ibsn_bit_64/models/60500_G.pth'
    
    def __init__(self):
        self._init_global_config()
        self._init_yaml_config()
        self.test_config = self.TestConfig()
    
    def _init_global_config(self):
        self.batch_size = 4
        self.num_workers = 8
        self.secret_image_path = "/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/dataset/locwatermark/blue.png"
        
    def _init_yaml_config(self):
        self.yaml_config = option.dict_to_nonedict(option.parse("options/train_editguard_bit.yml", is_train=True))
        self.yaml_config['dist'] = False
        self.yaml_config['datasets']['train']['data_path'] = os.path.join('/root/autodl-tmp/dataset/wo-sub/', os.getenv('TEST_MODE'))
        self.yaml_config['datasets']['train']['txt_path'] = os.path.join('/root/autodl-tmp/dataset/wo-sub/', os.getenv('TEST_MODE') + '.txt')
        self.yaml_config['logger']['log_dir'] = 'fine_tuning/log'
        self.yaml_config['path']['pretrain_model_G'] = '/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/checkpoints/clean.pth'
        # self.yaml_config['path']['resume_state'] = '/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/code/experiments/train_ibsn_bit_64-backup/training_state/250000.state'