export PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/code
cd $PROJECT_PATH

conda activate edit-gaurd

python -u fine_tuning/test.py -opt fine_tuning/options/train_editguard_bit.yml --c