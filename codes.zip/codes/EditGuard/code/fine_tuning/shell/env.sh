PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/EditGuard
cd $PROJECT_PATH

# ! Remove env
# conda activate base && \
# conda remove -n edit-gaurd --all -y

# ! Create env
# mamba create -n edit-gaurd python=3.10 -y && \
# conda activate edit-gaurd && \
# mamba install pytorch==2.1.2 torchvision==0.16.2 torchaudio==2.1.2 pytorch-cuda=12.1 -c pytorch -c nvidia -y && \
# mamba install pyyaml opencv einops diffusers -c conda-forge -y && \
# pip3 install basicsr transformers accelerate && \
# mamba install tensorboard tensorboardX pandas tabulate -c conda-forge -y

# ! Make pretrained model
# cd $PROJECT_PATH/checkpoints && \
# gdown --fuzzy https://drive.google.com/file/d/1w4e1gpdInAv7Lj_NQ7EGgmMuInyfUYgi/view?usp=sharing

# ! Make val dataset
# cd $PROJECT_PATH/dataset && \
# gdown --fuzzy https://drive.google.com/file/d/1s3HKFOzLokVplXV65Z6xcsBJ9qI91Qfv/view && \
# 7z x valAGE-Set.zip
# rm -rf valAGE-Set.zip

# ! Make train dataset