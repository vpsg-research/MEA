export PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/EditGuard && \
cd $PROJECT_PATH && \

7z a EditGuard-weight.7z \
/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/code/experiments \
/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/experiments/train_ibsn_bit_64/models/60500_G.pth \
/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/experiments/train_ibsn_bit_64/models/73500_G.pth \
/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/experiments/train_ibsn_bit_64/models/82500_G.pth \
/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/experiments/train_ibsn_bit_64/training_state/60500.state \
/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/experiments/train_ibsn_bit_64/training_state/73500.state \
/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/experiments/train_ibsn_bit_64/training_state/82500.state \
/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/experiments/train_ibsn_bit_64/train_train_ibsn_bit_64_250730-215444.log \
/root/autodl-tmp/Multi-Watermarking/Code/EditGuard/experiments/train_ibsn_bit_64/val_train_ibsn_bit_64_250730-215444.log && \

rclone copy EditGuard-weight.7z gdrive:EditGuard-weight.7z -P
rm EditGuard-weight.7z