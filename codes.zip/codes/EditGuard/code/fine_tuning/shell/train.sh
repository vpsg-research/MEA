nohup \
python -u fine_tuning/train_bit.py -opt fine_tuning/options/train_editguard_bit.yml \
> fine_tuning/log/train.log 2>&1 &

sleep 1

tail -f fine_tuning/log/train.log