PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/EditGuard
cd $PROJECT_PATH/code
export TEST_MODE=test
conda activate edit-gaurd

python -u fine_tuning/fine_tuning.py