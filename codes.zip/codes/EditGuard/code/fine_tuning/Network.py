from transformers.optimization import get_cosine_schedule_with_warmup
import torch
import numpy as np
import torch.nn as nn
from random import randint
import os
import sys
sys.path.append(os.getcwd())

# from MultiEnTest.Until import set_bn_track_running_stats
from models.IBSN import *

class FineTuningNetwork(Model_VSN):
    def __init__(self, opt, num_warmup_steps: int, num_training_steps: int):
        super().__init__(opt)
        self.scheduler = get_cosine_schedule_with_warmup(self.optimizer_G,   
                                                    num_warmup_steps=num_warmup_steps,  
                                                    num_training_steps=num_training_steps)
        self.message_length = opt['message_length']

    def optimize_parameters(self, current_step):
        # set_bn_track_running_stats(self.netG, track_stats=False)
        self.optimizer_G.zero_grad()
      
        b, n, t, c, h, w = self.ref_L.shape
        center = t // 2
        intval = self.gop // 2

        message = torch.Tensor(np.random.choice([-0.5, 0.5], (self.ref_L.shape[0], self.opt['message_length']))).to(self.device)

        add_noise = self.opt['addnoise']
        add_jpeg = self.opt['addjpeg']
        add_possion = self.opt['addpossion']
        add_sdinpaint = self.opt['sdinpaint']
        degrade_shuffle = self.opt['degrade_shuffle']

        self.host = self.real_H[:, center - intval:center + intval + 1]
        self.secret = self.ref_L[:, :, center - intval:center + intval + 1]
        self.output, encoded_image = self.netG(x=dwt(self.host.reshape(b, -1, h, w)), x_h=dwt(self.secret[:,0].reshape(b, -1, h, w)), message=message)

        Gt_ref = self.real_H[:, center - intval:center + intval + 1].detach()

        y_forw = encoded_image

        l_forw_fit = self.loss_forward(y_forw, self.host[:,0])

        # ============================== Add noise ============================== #
        if degrade_shuffle:
            import random
            choice = random.randint(0, 2)
            
            if choice == 0:
                NL = float((np.random.randint(1, 16))/255)
                noise = np.random.normal(0, NL, y_forw.shape)
                torchnoise = torch.from_numpy(noise).cuda().float()
                y_forw = y_forw + torchnoise

            elif choice == 1:
                NL = int(np.random.randint(70,95))
                self.DiffJPEG = DiffJPEG(differentiable=True, quality=int(NL)).cuda()
                y_forw = self.DiffJPEG(y_forw)
            
            elif choice == 2:
                vals = 10**4
                if random.random() < 0.5:
                    noisy_img_tensor = torch.poisson(y_forw * vals) / vals
                else:
                    img_gray_tensor = torch.mean(y_forw, dim=0, keepdim=True)
                    noisy_gray_tensor = torch.poisson(img_gray_tensor * vals) / vals
                    noisy_img_tensor = y_forw + (noisy_gray_tensor - img_gray_tensor)

                y_forw = torch.clamp(noisy_img_tensor, 0, 1)

        else:

            if add_noise:
                NL = float((np.random.randint(1,16))/255)
                noise = np.random.normal(0, NL, y_forw.shape)
                torchnoise = torch.from_numpy(noise).cuda().float()
                y_forw = y_forw + torchnoise

            elif add_jpeg:
                NL = int(np.random.randint(70,95))
                self.DiffJPEG = DiffJPEG(differentiable=True, quality=int(NL)).cuda()
                y_forw = self.DiffJPEG(y_forw)

            elif add_possion:
                vals = 10**4
                if random.random() < 0.5:
                    noisy_img_tensor = torch.poisson(y_forw * vals) / vals
                else:
                    img_gray_tensor = torch.mean(y_forw, dim=0, keepdim=True)
                    noisy_gray_tensor = torch.poisson(img_gray_tensor * vals) / vals
                    noisy_img_tensor = y_forw + (noisy_gray_tensor - img_gray_tensor)

                y_forw = torch.clamp(noisy_img_tensor, 0, 1)

        y = self.Quantization(y_forw) # 这种量化操作可以用于模拟图像数据在实际应用中的精度损失，例如在存储、传输或与其他低精度数据交互时
        all_zero = torch.zeros(message.shape).to(self.device)

        if self.mode == "image":
            out_x, out_x_h, out_z, recmessage = self.netG(x=y, message=all_zero, rev=True)
            out_x = iwt(out_x)
            out_x_h = [iwt(out_x_h_i) for out_x_h_i in out_x_h]

            l_back_rec = self.loss_back_rec(out_x, self.host[:,0])
            out_x_h = torch.stack(out_x_h, dim=1)

            l_center_x = self.loss_back_rec(out_x_h[:, 0], self.secret[:,0].reshape(b, -1, h, w))

            recmessage = torch.clamp(recmessage, -0.5, 0.5)

            l_msg = self.Reconstruction_msg(message, recmessage)

            loss = l_forw_fit*2 + l_back_rec + l_center_x*4

            loss.backward()

            if self.train_opt['lambda_center'] != 0:
                self.log_dict['l_center_x'] = l_center_x.item()

            # set log
            self.log_dict['l_back_rec'] = l_back_rec.item()
            self.log_dict['l_forw_fit'] = l_forw_fit.item()
            self.log_dict['l_msg'] = l_msg.item()
            
            self.log_dict['l_h'] = (l_center_x*10).item()

            # gradient clipping
            if self.train_opt['gradient_clipping']:
                nn.utils.clip_grad_norm_(self.netG.parameters(), self.train_opt['gradient_clipping'])

            self.optimizer_G.step()

        elif self.mode == "bit":
            recmessage = self.netG(x=y, message=all_zero, rev=True)
            recmessage = torch.clamp(recmessage, -0.5, 0.5)
            l_msg = self.Reconstruction_msg(message, recmessage)
            
            # ========================= Doulbe watermarking ========================= #
            double_encoded_image = y.clone()
            for i in range(1, randint(1, 3)):
                double_message = torch.Tensor(np.random.choice([-0.5, 0.5], (self.ref_L.shape[0], self.opt['message_length']))).to(self.device)
                _, double_encoded_image = self.netG(x=dwt(double_encoded_image), x_h=dwt(self.secret[:,0].reshape(b, -1, h, w)), message=double_message)
            
            double_y = self.Quantization(double_encoded_image)
            
            double_decoded_message = self.netG(x=double_y, message=all_zero, rev=True)
            l_double_msg = self.Reconstruction_msg(message, double_decoded_message)
            
            loss = (
                l_msg * self.train_opt['lambda_msg'] + 
                l_double_msg * self.train_opt['lambda_msg'] +
                l_forw_fit
            )

            loss.backward()

            # set log
            self.log_dict['l_forw_fit'] = l_forw_fit.item()
            self.log_dict['l_msg'] = l_msg.item()
            self.log_dict['l_double_msg'] = l_double_msg.item()
            

            # gradient clipping
            if self.train_opt['gradient_clipping']:
                nn.utils.clip_grad_norm_(self.netG.parameters(), self.train_opt['gradient_clipping'])

            self.optimizer_G.step()
