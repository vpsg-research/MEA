import os
import sys
from torch.utils.data import DataLoader
from PIL import Image
import torch.nn as nn
sys.path.append(os.getcwd())
sys.path.append(os.path.dirname(os.getcwd()))

from multi_encoding_test.Test import MultiEnTester, getImageOrigin
from fine_tuning import *
from Network import FineTuningNetwork
from utils import ImageDataset

class Tester(MultiEnTester):
    def __init__(self, name, network_origin, network_double, test_loader, CustomDataset):
        super().__init__(name, network_origin, network_double, test_loader, CustomDataset)
        self.criterion_MSE = nn.MSELoss()
    
    def calculate_bit_error_rate(self, original_message: torch.Tensor, decoded_message: torch.Tensor) -> float:
        return self.criterion_MSE(original_message, decoded_message).item()
    
    def generate_message(self, batch_size, message_length):
        return torch.randint(0, 2, size=(batch_size, message_length), dtype=torch.float32)
    
    def encode(self, network: FineTuningNetwork, image, message):
        return network.encoder(image, message)
    
    def decode(self, network: FineTuningNetwork, image):
        return network.decoder(image)
    
    def encode_decode(self, network, image, message):
        image_encode = network.encoder(image, message)
        message_decode = network.decoder(image_encode)
        return image_encode, image_encode, message_decode

    def test_encode_decode(self, network, double_encoding_num: int, type: str="origin") -> dict:
        res = {
            'BER': 0.0,
            'MBER': 0.0,
            'PSNR': 0.0,
            'SSIM': 0.0, 
            'MPSNR': 0.0,
            'MSSIM': 0.0
        }
        
        for i, (image, name, image_origin, message) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with encoding {double_encoding_num} Testing'):
            batch_size = image.shape[0]
            image = image.to(network.device)
            message = message.to(network.device)
            encoded_images, noised_images, decoded_messages = self.encode_decode(network, image, message)
            # print(message.shape)
            # Add multiple watermark
            double_encoded_images = noised_images
            for j in range(double_encoding_num):
                double_message = self.generate_message(batch_size, network.message_length).to(network.device)
                double_encoded_images, _, double_decoded_messages = self.encode_decode(network, double_encoded_images, double_message)

            res['PSNR'] += self.get_psnr(image, encoded_images)
            res['SSIM'] += self.get_ssim(image, encoded_images)
            res['MPSNR'] += self.get_psnr(image, double_encoded_images)
            res['MSSIM'] += self.get_ssim(image, double_encoded_images)
            res['BER'] += self.calculate_bit_error_rate(message, decoded_messages)
            res['MBER'] += self.calculate_bit_error_rate(message, double_decoded_messages)
            self.save_image(image_origin, encoded_images, double_encoded_images, name, double_encoding_num+1, os.path.join(self.result_adapter.folders['repository'], type))
            self.save_message(message, name, os.path.join(self.result_adapter.folders['repository'], type))
        res = {key: value / len(self.test_loader) for key, value in res.items()}
        return res

    def test_across_model_encode_specific(self, network, number_mutiple_encoding: int, type: str, name_model: str):
        for i, (image, name, message, correct_message) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with encoding {number_mutiple_encoding} Testing'):
            batch_size = image.shape[0]
            image = image.to(network.device)
            message = self.generate_message(batch_size, network.message_length).to(network.device)
            encoded_images, noised_images, decoded_messages = self.encode_decode(network, image, message)
            
            # Add multiple watermark
            double_encoded_images = noised_images
            for j in range(number_mutiple_encoding):
                double_message = self.generate_message(batch_size, network.message_length).to(network.device)
                double_encoded_images, _, double_decoded_messages = self.encode_decode(network, double_encoded_images, double_message)
            
            for idx, n in enumerate(name):
                self.general_save_image(
                    double_encoded_images[idx], 
                    os.path.join(
                        self.result_adapter.common_result_folder, 
                        name_model, 
                        'repository',
                        type, 
                        n, 
                        'watermarked'
                    ), 
                    f"{self.name}-{number_mutiple_encoding}.png"
                )

    def test_across_model_decode_specific(self, network, number_mutiple_encoding: int, type: str):
        res = {
            'XBER': 0.0,
        }
        
        for i, (image, name, message, correct_message) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with xdecoding {number_mutiple_encoding} Testing'):
            image, message = image.to(network.device), message.to(network.device)
            decoded_messages = self.decode(network, image)
            res['XBER'] += self.calculate_bit_error_rate(message, decoded_messages)
        res = {key: value / len(self.test_loader) for key, value in res.items()}
        return res
                
class TestDataset(ImageDataset):
    def __init__(self, path_img, path_wm, img_size, wm_len, mode='train'):
        super().__init__(path_img, path_wm, img_size, wm_len, mode)
        self.transform = transforms.Compose([
            transforms.Resize((self.img_size, self.img_size)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.5, 0.5, 0.5],
                std=[0.5, 0.5, 0.5]
            )
        ])

    def __getitem__(self, idx):
        wm_name = self.lst_wm[idx]
        img_name = self.get_image_name_from_wm(wm_name)
        img = Image.open(os.path.join(self.path_img, img_name)).convert('RGB')
        wm = np.load(os.path.join(self.path_wm, wm_name))
        img = self.transform_image(img)
        name_image = img_name[:-4]
        return img, name_image, getImageOrigin(os.path.join(self.path_img, img_name)), torch.Tensor(wm)

class RepoModelDataset(ImageDataset):
    def __init__(self, dataset_path, name_model, number_encode):
        super().__init__(
            dataset_path, 
            os.path.join('/root/autodl-tmp/dataset/LampMark-wm-data', os.getenv('TEST_MODE')), 
            configs.img_size, 
            configs.watermark_length, 
            'train'
        )
        self.transform = transforms.Compose([
            transforms.Resize((self.img_size, self.img_size)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.5, 0.5, 0.5],
                std=[0.5, 0.5, 0.5]
            )
        ])
        self.dataset_path = dataset_path
        self.name_model = name_model
        self.number_encode = number_encode
        
    def __getitem__(self, idx):
        wm_name = self.lst_wm[idx]
        img_name = self.get_image_name_from_wm(wm_name)[:-4]
        # img = Image.open(os.path.join(self.path_img, img_name)).convert('RGB')
        img = Image.open(os.path.join(self.path_img, img_name, "watermarked", f"{self.name_model}-{self.number_encode}.png")).convert('RGB')
        wm = np.load(os.path.join(self.path_wm, wm_name))
        img = self.transform_image(img)
        name_image = img_name
        return img, name_image, torch.from_numpy(np.load(os.path.join(self.path_img, img_name, "message.npy"))), torch.Tensor(wm)

if __name__ == '__main__':
    path_resume_encoder = 'fine_tuning/weights/256_128/deepfake/encoder_epoch_20.pth'
    path_resume_decoder = 'fine_tuning/weights/256_128/deepfake/decoder_epoch_20.pth'
    path_resume_discriminator = 'fine_tuning/weights/256_128/deepfake_discriminator/epoch_20.pth'
    
    configs = JsonConfig()
    configs.load_json_file('fine_tuning/config/fine_tuning.json')
    
    configs.wm_path = '/root/autodl-tmp/dataset/LampMark-wm-data/' + os.getenv("TEST_MODE")
    
    network_origin = FineTuningNetwork(configs, device)
    network_origin.load_model(encoder_path=configs.encoder_path, decoder_path=configs.decoder_path)
    network_origin.load_discriminator(configs.discriminator_path)
    
    network_multiple = FineTuningNetwork(configs, device)
    network_multiple.load_model(encoder_path=path_resume_encoder, decoder_path=path_resume_decoder)
    network_multiple.load_discriminator(path_resume_discriminator)

    dataset = TestDataset(
        os.path.join(configs.img_path, os.getenv('TEST_MODE')),
        os.path.join('/root/autodl-tmp/dataset/LampMark-wm-data', os.getenv('TEST_MODE')),
        configs.img_size,
        configs.watermark_length
    )
    test_dataloader = DataLoader(dataset, batch_size=configs.batch_size, num_workers=0, shuffle=False)

    loss_record_train = define_result_dict(configs, 'list')
    loss_record_val = define_result_dict(configs, 'list')
    
    tester = Tester(
        name="LampMark", 
        network_origin=network_origin, 
        network_double=network_multiple, 
        test_loader=test_dataloader, 
        CustomDataset=RepoModelDataset
    )
    
    tester.test(double_encoding_num=5, gen_summary=True)