import os
import sys
sys.path.append(os.getcwd())
from main import *
from Network import FineTuningNetwork

def tune_deepfake():
    configs = JsonConfig()
    configs.load_json_file('fine_tuning/config/fine_tuning.json')
    trainer = FineTuningNetwork(configs, device)

    # ! Load the second period trained model
    trainer.load_model(encoder_path=configs.encoder_path, decoder_path=configs.decoder_path)
    trainer.load_discriminator(configs.discriminator_path)

    train_loader = make_loader(configs, model_mode='train', shuffle=True)
    val_loader = make_loader(configs, model_mode='val', shuffle=False)

    loss_record_train = define_result_dict(configs, 'list')
    loss_record_val = define_result_dict(configs, 'list')

    print('Training on going ...')
    for epoch in range(configs.epochs):
        start_time = time.time()
        running_result = define_result_dict(configs,  'value')

        # Train
        batch_count = 0
        for imgs, watermarks in tqdm(train_loader):
            result = trainer.tune_batch_simswap(imgs, watermarks)
            for key in running_result:
                running_result[key] += float(result[key])
            batch_count += 1

        log_text = 'Epoch ' + str(epoch + 1) + ': ' + format_time(time.time() - start_time) + ' elapsed.\n'
        for key in running_result:
            log_text = log_text + key + '=' + str(running_result[key] / batch_count) + '\n'
            loss_record_train[key].append(float(running_result[key] / batch_count))
        log_text = log_text + '\n'

        if not os.path.exists('./fine_tuning/results/deepfake'):
            os.makedirs('./fine_tuning/results/deepfake')
        with open('./fine_tuning/results/deepfake/train_log.txt', 'a') as file:
            file.write(log_text)
        print(log_text)

        encoder_path = configs.weight_path + '/deepfake/encoder_epoch_' + str(epoch + 1) + '.pth'
        decoder_path = configs.weight_path + '/deepfake/decoder_epoch_' + str(epoch + 1) + '.pth'
        discriminator_path = configs.weight_path + '/deepfake_discriminator/epoch_' + str(epoch + 1) + '.pth'
        trainer.save_model(encoder_path, decoder_path, discriminator_path)

        # Validation
        if configs.do_validation:
            start_time = time.time()
            running_result = define_result_dict(configs, 'value')

            save_iters = np.random.choice(np.arange(len(val_loader)), size=configs.save_img_nums, replace=False)
            save_imgs = None
            batch_count = 0
            for imgs, watermarks in tqdm(val_loader):
                result, output_lst = trainer.val_batch_simswap(imgs, watermarks)
                for key in running_result:
                    running_result[key] += float(result[key])

                if batch_count in save_iters:
                    if save_imgs is None:
                        if True:  # epoch % 2 == 0:
                            save_imgs = get_random_images(output_lst[0], output_lst[1], output_lst[2])
                        else:
                            save_imgs = get_random_images(output_lst[0], output_lst[1], output_lst[3])
                    else:
                        if True:  # epoch % 2 == 0:
                            save_imgs = concatenate_images(save_imgs, output_lst[0], output_lst[1], output_lst[2])
                        else:
                            save_imgs = concatenate_images(save_imgs, output_lst[0], output_lst[1], output_lst[3])
                batch_count += 1

            log_text = 'Validation finished in ' + format_time(time.time() - start_time) + '.\n'
            for key in running_result:
                log_text = log_text + key + '=' + str(running_result[key] / batch_count) + '\n'
                loss_record_val[key].append(float(running_result[key] / batch_count))
            log_text = log_text + '\n'
            print(log_text)
            save_images(
                save_imgs, epoch + 1, './fine_tuning/results/images_deepfake', resize_to=(configs.img_size, configs.img_size)
            )

    plot_curves(configs.epochs, loss_record_train, loss_record_val, './fine_tuning/results/deepfake')


if __name__ == '__main__':
    tune_deepfake()