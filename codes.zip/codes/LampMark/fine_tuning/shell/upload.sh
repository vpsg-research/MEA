PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/LampMark
cd $PROJECT_PATH && \

7z a LampMark-weight.7z \
weights/256_128/deepfake/decoder_epoch_50.pth \
weights/256_128/deepfake/encoder_epoch_50.pth \
weights/256_128/deepfake_discriminator/epoch_50.pth \
weights/256_128/wm-img/model_epoch_56.pth \
results \
fine_tuning/results \
fine_tuning/weights/256_128/deepfake/decoder_epoch_20.pth \
fine_tuning/weights/256_128/deepfake/encoder_epoch_20.pth \
fine_tuning/weights/256_128/deepfake_discriminator/epoch_20.pth && \
rclone copy LampMark-weight.7z gdrive:ModelWeights -P