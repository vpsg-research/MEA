cd /root/autodl-tmp/Multi-Watermarking/Code/LampMark

# ! Remove env
conda activate base && \
mamba env remove -n lamp-mark -y

# ! Create env
mamba create -n lamp-mark python=3.9 -y && \
conda activate lamp-mark && \
pip install uv && \
mamba install pytorch==1.12.1 torchvision==0.13.1 torchaudio==0.12.1 cudatoolkit=11.3 -c pytorch -y && \
mamba install mkl=2021.4.0 scipy ninja matplotlib -c conda-forge -y && \
export UV_CACHE_DIR=/root/autodl-tmp/.uv_cache && \
uv pip install kornia==0.6.8 tqdm==4.64.1 pyecharts==1.9.1 opencv-python==4.6.0.66 scikit-image face_alignment munch ffmpeg pandas tabulate && \

python -c "import torch; print(f'PyTorch版本: {torch.__version__}, CUDA可用: {torch.cuda.is_available()}')" && \
python -c "import torch; from torch.utils.cpp_extension import verify_ninja_availability; verify_ninja_availability(); print('Ninja已正确安装')"