PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/LampMark
cd $PROJECT_PATH && \

rclone copy gdrive:ModelWeights/LampMark-weight.7z . -P && \
7z x LampMark-weight.7z && \
rm LampMark-weight.7z
