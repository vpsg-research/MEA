export PROJECT_PATH="/root/autodl-tmp/Multi-Watermarking/Code/LampMark"

# ! Activate env
cd $PROJECT_PATH && \
conda activate lamp-mark && \

# ! Train
python fine_tuning/test.py --checkpoints_dir $PROJECT_PATH/model/SimSwap/checkpoints