from easydict import EasyDict
import yaml
import time
from torch.utils.data import DataLoader
from tqdm import tqdm
import sys
import os
from torchmetrics.image import PeakSignalNoiseRatio, StructuralSimilarityIndexMeasure
sys.path.append(os.getcwd())
sys.path.append(os.path.dirname(os.getcwd()))

from multi_encoding_test.Test import MultiEnTester
from multi_encoding_test.Test import getImageOrigin
from network.Dual_Mark import Network
from Network import *
from utils import *

class Tester(MultiEnTester):
    def __init__(self, name, network_origin: Network, network_double: FineTuningNetwork, test_loader, CustomDataset):
        super().__init__(name, network_origin, network_double, test_loader, CustomDataset)
    
    def calculate_bit_error_rate(self, original_message, decoded_message):
        # Single picture
        def decoded_message_error_rate(message, decoded_message):
            length = message.shape[0]
            message = message.gt(0)
            decoded_message = decoded_message.gt(0)
            error_rate = float(sum(message != decoded_message)) / length
            return error_rate
        # Batch
        error_rate = 0.0
        batch_size = len(original_message)
        for i in range(batch_size):
            error_rate += decoded_message_error_rate(original_message[i], decoded_message[i])
        error_rate /= batch_size
        return error_rate
    
    def generate_message(self, batch_size, message_length):
        # ! Must define gobal message range
        return torch.Tensor(np.random.choice([-message_range, message_range], (batch_size, message_length))).to(self.network_origin.device)
    
    def decode(self, network, image):
        decoded_message = network.encoder_decoder.module.decoder_C(image)
        return decoded_message
    
    def encode_decode(self, network: FineTuningNetwork, image, message, mask):
        encoded_images, noised_images, decoded_messages_C, decoded_messages_R, decoded_messages_F = network.encoder_decoder(image, message, mask)
        return noised_images, noised_images, decoded_messages_C
    
    def test_encode_decode(self, network, double_encoding_num: int, type: str="origin") -> dict:
        res = {
            'BER': 0.0,
            'MBER': 0.0,
            'PSNR': 0.0,
            'SSIM': 0.0, 
            'MPSNR': 0.0,
            'MSSIM': 0.0
        }
        
        for i, (image, name, image_origin, mask) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with encoding {double_encoding_num} Testing'):
            batch_size = image.shape[0]
            image = image.to(network.device)
            image_origin = image_origin.to(network.device)
            message = self.message.repeat(batch_size, 1).to(network.device)
            encoded_images, noised_images, decoded_messages = self.encode_decode(network, image, message, mask)
            
            # Add multiple watermark
            double_encoded_images = noised_images
            for j in range(double_encoding_num):
                double_message = self.generate_message(batch_size, network.message_length).to(network.device)
                double_encoded_images, _, double_decoded_messages = self.encode_decode(network, double_encoded_images, double_message, mask)

            res['PSNR'] += self.get_psnr(image, encoded_images)
            res['SSIM'] += self.get_ssim(image, encoded_images)
            res['MPSNR'] += self.get_psnr(image, double_encoded_images)
            res['MSSIM'] += self.get_ssim(image, double_encoded_images)
            res['BER'] += self.calculate_bit_error_rate(message, decoded_messages)
            res['MBER'] += self.calculate_bit_error_rate(message, double_decoded_messages)
            self.save_image(image_origin, encoded_images, double_encoded_images, name, double_encoding_num+1, os.path.join(self.result_adapter.folders['repository'], type))
            self.save_message(message, name, os.path.join(self.result_adapter.folders['repository'], type))
        res = {key: value / len(self.test_loader) for key, value in res.items()}
        return res
    
    def test_across_model_decode_specific(self, network, number_mutiple_encoding: int, type: str):
        res = {
            'XBER': 0.0,
        }
        
        for i, (image, name, message, mask) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with xdecoding {number_mutiple_encoding} Testing'):
            image = image.to(network.device)
            message = message.to(network.device)
            decoded_messages = self.decode(network, image)
            # print(f"original message shape: {message}, decoded message shape: {decoded_messages}")
            res['XBER'] += self.calculate_bit_error_rate(message, decoded_messages)
        res = {key: value / len(self.test_loader) for key, value in res.items()}
        return res
    
    def test_across_model_encode_specific(self, network, number_mutiple_encoding: int, type: str, name_model: str):
        for i, (image, name, message, mask) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with encoding {number_mutiple_encoding} Testing'):
            batch_size = image.shape[0]
            image = image.to(network.device)
            message = self.generate_message(batch_size, network.message_length).to(network.device)
            encoded_images, noised_images, decoded_messages = self.encode_decode(network, image, message, mask)
            
            # Add multiple watermark
            double_encoded_images = noised_images
            for j in range(number_mutiple_encoding):
                double_message = self.generate_message(batch_size, network.message_length).to(network.device)
                double_encoded_images, _, double_decoded_messages = self.encode_decode(network, double_encoded_images, double_message, mask)
            
            for idx, n in enumerate(name):
                self.general_save_image(
                    double_encoded_images[idx], 
                    os.path.join(
                        self.result_adapter.common_result_folder, 
                        name_model, 
                        'repository',
                        type, 
                        n, 
                        'watermarked'
                    ), 
                    f"{self.name}-{number_mutiple_encoding}.png"
                )
    
class TestDataset(attrsImgDataset):
    def __getitem__(self, index):
        """Return one image and its corresponding attribute label."""
        name, label = self.list[index]
        path_image = os.path.join(self.image_dir, name)
        image = self.transform(Image.open(path_image).convert("RGB"))
        name = name[:-4]
        image_origin = getImageOrigin(path_image)
        mask = torch.FloatTensor(label)
        return image, name, image_origin, mask

class RepoModelDataset(attrsImgDataset):
    def __init__(self, dataset_path, name_model:str=None, image_size=256, attr_path="celebahq", number_encode=1):
        '''
        `original` is used for control encode/decode mode
        '''
        super().__init__(dataset_path, image_size, attr_path)
        self.name_model = name_model
        self.number_encode = number_encode
        
    def preprocess(self):
        """Preprocess the CelebA attribute file."""
        lines = [line.rstrip() for line in open(self.attr_path, 'r')]
        all_attr_names = lines[1].split()
        for i, attr_name in enumerate(all_attr_names):
            self.attr2idx[attr_name] = i
            self.idx2attr[i] = attr_name

        lines = lines[2:]
        for i, line in enumerate(lines):
            split = line.split()
            basename = os.path.basename(split[0])
            filename = str(os.path.splitext(basename)[0]).zfill(5)
            values = split[1:]

            label = []
            for attr_name in self.selected_attrs:
                idx = self.attr2idx[attr_name]
                label.append(values[idx] == '1')
            
            if os.path.exists(os.path.join(self.image_dir, filename, "original.png")):
                self.list.append([filename, label])

    def __getitem__(self, index):
        """Return one image and its corresponding attribute label."""
        name, label = self.list[index]
        image = self.transform(Image.open(os.path.join(self.image_dir, name, "watermarked", f"{self.name_model}-{self.number_encode}.png")).convert("RGB"))
        message = torch.from_numpy(np.load(os.path.join(self.image_dir, name, "message.npy")))
        return image, name, message, torch.FloatTensor(label)

if __name__ == '__main__':
    # =========================== Init params ========================== #
    with open('fine_tuning/config/test_DoubleWatermarkingAttack.yaml', 'r') as f:
        args = EasyDict(yaml.load(f, Loader=yaml.SafeLoader))            
    project_name = args.project_name
    epoch_number = args.epoch_number
    batch_size = args.batch_size
    lr = args.lr
    beta1 = args.beta1
    image_size = args.image_size
    message_length = args.message_length
    message_range = args.message_range
    attention_encoder = args.attention_encoder
    attention_decoder = args.attention_decoder
    weight = args.weight
    dataset_path = args.dataset_path
    save_images_number = args.save_images_number
    noise_layers_R = args.noise_layers.pool_R
    noise_layers_F = args.noise_layers.pool_F
    
    # val_dataset_path = os.path.join(dataset_path, "test_" + str(image_size))
    val_dataset_path = os.path.join(dataset_path, os.getenv("TEST_MODE"))
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    if noise_layers_R is None:
        noise_layers_R = []
    if noise_layers_F is None:
        noise_layers_F = []
    
    # ========================== Init network ========================== #
    network_origin = FineTuningNetwork(message_length, noise_layers_R, noise_layers_F, device, batch_size, lr, beta1, attention_encoder, attention_decoder, weight, message_range)
    network_double_watermark = FineTuningNetwork(message_length, noise_layers_R, noise_layers_F, device, batch_size, lr, beta1, attention_encoder, attention_decoder, weight, message_range)
    network_origin.load_model(
        args.compare_path_config.encoder_decoder_model.origin, 
        args.compare_path_config.discriminator_model.origin, 
    )
    network_double_watermark.load_model(
        args.compare_path_config.encoder_decoder_model.double_watermarking, 
        args.compare_path_config.discriminator_model.double_watermarking, 
    )   
    
    test_dataset = TestDataset(val_dataset_path, image_size, "celebahq")
    assert len(test_dataset) > 0, "test dataset is empty"
    test_dataloader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=True)
    
    tester = Tester(
        name="SepMark", 
        network_origin=network_origin, 
        network_double=network_double_watermark, 
        test_loader=test_dataloader, 
        CustomDataset=RepoModelDataset
    )
    
    tester.test(double_encoding_num=5, gen_summary=True)