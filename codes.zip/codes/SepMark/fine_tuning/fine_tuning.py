import yaml
from easydict import EasyDict
import os
import time
from shutil import copyfile
import random
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
import pandas as pd
import sys
sys.path.append(os.getcwd())
print(sys.path)

from Network import *
from utils import *

def seed_torch(seed=42):
    seed = int(seed)
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.enabled = True


def main():
    # ========================== Init dataset ========================== #
    train_dataset = attrsImgDataset(train_dataset_path, image_size, "celebahq")
    #train_dataset = maskImgDataset(os.path.join(dataset_path, "train_" + str(image_size)), image_size)
    assert len(train_dataset) > 0, "train dataset is empty"
    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0, pin_memory=True)
    
    val_dataset = attrsImgDataset(val_dataset_path, image_size, "celebahq")
    assert len(val_dataset) > 0, "val dataset is empty"
    #val_dataset = maskImgDataset(os.path.join(dataset_path, "val_" + str(image_size)), image_size)
    val_dataloader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=True)
    
    # ========================== Init network ========================== #
    network = FineTuningNetwork(message_length, noise_layers_R, noise_layers_F, device, batch_size, lr, beta1, attention_encoder, attention_decoder, weight, message_range, num_warmup_steps=len(train_dataloader)*0.1, num_training_steps=len(train_dataloader)*5)
    if args.resume_config.resume:
        network.load_model(
            args.resume_config.encoder_decoder_model_path, 
            args.resume_config.discriminator_model_path, 
        )

    # =========================== Train & Val ========================== #
    print("\nStart training : \n\n")

    # print(1 if not args.resume_config.resume else args.resume_config.start_epoch, epoch_number + 1)
    for epoch in tqdm(
        range(1 if not args.resume_config.resume else args.resume_config.start_epoch, epoch_number + 1), 
        desc='Epoch', 
        total=epoch_number + 1 - (1 if not args.resume_config.resume else args.resume_config.start_epoch)
    ):        
        # ============================== Train ============================= #
        running_result = {
            "g_loss": 0.0,
            "error_rate_C": 0.0,
            "error_rate_R": 0.0,
            "error_rate_F": 0.0,
            "psnr": 0.0,
            "ssim": 0.0,
            "g_loss_on_discriminator": 0.0,
            "g_loss_on_encoder_MSE": 0.0,
            "g_loss_on_encoder_LPIPS": 0.0,
            "g_loss_on_decoder_C": 0.0,
            "g_loss_on_decoder_R": 0.0,
            "g_loss_on_decoder_F": 0.0,
            "d_loss": 0.0,
            "g_loss_on_double_watermark": 0.0, 
			"double_error_rate_C": 0.0,
			"double_error_rate_R": 0.0,
			"double_error_rate_F": 0.0, 
            "double_psnr": 0.0, 
            "double_ssim": 0.0
        }
        start_time = time.time()
        
        for step, (image, mask) in tqdm(enumerate(train_dataloader, 1), desc=f'Step (on Epoch {epoch})', total=len(train_dataloader)):
            writer.add_scalar("lr", network.scheduler.get_last_lr()[0], (epoch - 1) * len(train_dataloader) + step)
            image = image.to(device)
            message = torch.Tensor(np.random.choice([-message_range, message_range], (image.shape[0], message_length))).to(device)

            result = network.train(image, message, mask)

            # print('Epoch: {}/{} Step: {}/{}'.format(epoch, epoch_number, step, len(train_dataloader)))

            for key in result:
                # print(key, float(result[key]))
                writer.add_scalar(
                    "Train/" + key, 
                    float(result[key]), 
                    (epoch - 1) * len(train_dataloader) + step
                )
                running_result[key] += float(result[key])

        # Train results
        content = "Epoch " + str(epoch) + " : " + str(int(time.time() - start_time)) + "\n"
        for key in running_result:
            content += key + "=" + str(running_result[key] / step) + ","
            writer.add_scalar("Train_epoch/" + key, float(running_result[key] / step), epoch)
        content += "\n"
        

        with open(result_folder + "/train_log.txt", "a") as file:
            file.write(content)
        # print(content)

        # =========================== Validation =========================== #
        val_result = {
            "g_loss": 0.0,
            "error_rate_C": 0.0,
            "error_rate_R": 0.0,
            "error_rate_F": 0.0,
            "psnr": 0.0,
            "ssim": 0.0,
            "g_loss_on_discriminator": 0.0,
            "g_loss_on_encoder_MSE": 0.0,
            "g_loss_on_encoder_LPIPS": 0.0,
            "g_loss_on_decoder_C": 0.0,
            "g_loss_on_decoder_R": 0.0,
            "g_loss_on_decoder_F": 0.0,
            "d_loss": 0.0,
            "g_loss_on_double_watermark": 0.0, 
			"double_error_rate_C": 0.0,
			"double_error_rate_R": 0.0,
			"double_error_rate_F": 0.0, 
            "double_psnr": 0.0, 
            "double_ssim": 0.0
        }
        start_time = time.time()

        saved_iterations = np.random.choice(np.arange(1, len(val_dataloader)+1), size=save_images_number, replace=False)
        saved_all = None

        for step, (image, mask) in enumerate(val_dataloader, 1):
            image = image.to(device)
            message = torch.Tensor(np.random.choice([-message_range, message_range], (image.shape[0], message_length))).to(device)

            result, (images, encoded_images, noised_images) = network.validation(image, message, mask)

            print('Epoch: {}/{} Step: {}/{}'.format(epoch, epoch_number, step, len(val_dataloader)))
            for key in result:
                # print(key, float(result[key]))
                writer.add_scalar("Val/" + key, float(result[key]), (epoch - 1) * len(val_dataloader) + step)
                val_result[key] += float(result[key])

            if step in saved_iterations:
                if saved_all is None:
                    saved_all = get_random_images(image, encoded_images, noised_images)
                else:
                    saved_all = concatenate_images(saved_all, image, encoded_images, noised_images)

        save_images(saved_all, epoch, result_folder + "images/", resize_to=None)

        # Validation results
        content = "Epoch " + str(epoch) + " : " + str(int(time.time() - start_time)) + "\n"
        for key in val_result:
            content += key + "=" + str(val_result[key] / step) + ","
            writer.add_scalar("Val_epoch/" + key, float(val_result[key] / step), epoch)
        content += "\n"

        with open(result_folder + "/val_log.txt", "a") as file:
            file.write(content)
        # print(f"\nEpoch {epoch} Validation results: \n")
        # print(content)

        # Save model
        path_model = result_folder + "models/"
        path_encoder_decoder = path_model + "EC_" + str(epoch) + ".pth"
        path_discriminator = path_model + "D_" + str(epoch) + ".pth"
        network.save_model(path_encoder_decoder, path_discriminator)

    


if __name__ == '__main__':
    # exp_name = "TestIncorrectMessageRangeFullFineTuning"
    # exp_name = "FullFineTuningWithDecay"
    exp_name = "FullFineTuningWithOnlyMessage"
    description = (
        "1. Only double message loss is applied."
    )
    
    seed_torch(42) # it does not work if the mode of F.interpolate is "bilinear"
    # ======================= Init configuration ======================= #
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"\nUsing device: {device}")
    with open('fine_tuning/config/train_DualMark.yaml', 'r') as f:
        args = EasyDict(yaml.load(f, Loader=yaml.SafeLoader))
    project_name = args.project_name
    epoch_number = args.epoch_number
    batch_size = args.batch_size
    lr = args.lr
    beta1 = args.beta1
    image_size = args.image_size
    message_length = args.message_length
    message_range = args.message_range
    attention_encoder = args.attention_encoder
    attention_decoder = args.attention_decoder
    weight = args.weight
    dataset_path = args.dataset_path
    print(dataset_path)
    save_images_number = args.save_images_number
    noise_layers_R = args.noise_layers.pool_R
    noise_layers_F = args.noise_layers.pool_F    
    # train_dataset_path = os.path.join(dataset_path, "train_" + str(image_size))
    # val_dataset_path = os.path.join(dataset_path, "val_" + str(image_size))
    train_dataset_path = os.path.join(dataset_path, "train")
    val_dataset_path = os.path.join(dataset_path, "val")
        
    if noise_layers_R is None:
        noise_layers_R = []
    if noise_layers_F is None:
        noise_layers_F = []

    assert os.path.exists(train_dataset_path), "train dataset is not exist"
    assert os.path.exists(val_dataset_path), "val dataset is not exist"

    project_name += "_" + str(image_size) + "_" + str(message_length) + "_" + str(message_range) + "_" + str(lr) + "_" + str(beta1) + "_" + attention_encoder + "_" + attention_decoder
    for i in weight:
        project_name += "_" +  str(i)
    result_folder = "results/" + exp_name + "/"
    if not os.path.exists(result_folder): os.mkdir(result_folder)
    if not os.path.exists(result_folder + "images/"): os.mkdir(result_folder + "images/")
    if not os.path.exists(result_folder + "models/"): os.mkdir(result_folder + "models/")
    copyfile("fine_tuning/config/train_DualMark.yaml", result_folder + "train_DualMark.yaml")    
    
    writer = SummaryWriter('runs/'+ exp_name)
    
    writer.add_text("profile", pd.DataFrame(list({
        "project_name": project_name, 
        "description": description, 
        "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        "encoder_decoder_model_path": args.resume_config.encoder_decoder_model_path, 
        "discriminator_model_path": args.resume_config.discriminator_model_path, 
        "recommend_filter_regex": r"^(?!Test).*error_rate", 
        "device": device,
        "batch_size": batch_size,
        "lr": lr,
        "epoch_number": epoch_number,
        "message_length": message_length,
        "save_images_number": save_images_number,
        "dataset_path": dataset_path
    }.items()), columns=['key', 'value']).to_markdown(index=False))
    
    main()
    writer.close()
