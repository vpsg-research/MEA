cd /root/autodl-tmp/Multi-Watermarking/Code/SepMark

# ! Remove env
conda activate base
conda env remove -n WhatMark_wxs --all -y

# ! Create env
echo "
name: WhatMark_wxs
channels:
  - defaults
  - conda-forge
dependencies:
  - _libgcc_mutex=0.1=main
  - _openmp_mutex=5.1=1_gnu
  - ca-certificates=2022.12.7=ha878542_0
  - certifi=2022.12.7=pyhd8ed1ab_0
  - dlib=19.24.0=py38he2161a6_0
  - jpeg=9e=h166bdaf_1
  - ld_impl_linux-64=2.38=h1181459_1
  - libblas=3.9.0=15_linux64_openblas
  - libcblas=3.9.0=15_linux64_openblas
  - libffi=3.3=he6710b0_2
  - libgcc-ng=11.2.0=h1234567_1
  - libgfortran-ng=12.2.0=h69a702a_19
  - libgfortran5=12.2.0=h337968e_19
  - libgomp=11.2.0=h1234567_1
  - liblapack=3.9.0=15_linux64_openblas
  - libopenblas=0.3.20=pthreads_h78a6416_0
  - libpng=1.6.39=h5eee18b_0
  - libstdcxx-ng=11.2.0=h1234567_1
  - ncurses=6.4=h6a678d5_0
  - openssl=1.1.1t=h7f8727e_0
  - pip=22.3.1=py38h06a4308_0
  - python=3.8.13=haa1d7c7_1
  - python_abi=3.8=2_cp38
  - readline=8.2=h5eee18b_0
  - setuptools=65.6.3=py38h06a4308_0
  - sqlite=3.40.1=h5082296_0
  - tk=8.6.12=h1ccaba5_0
  - wheel=0.38.4=py38h06a4308_0
  - xz=5.2.10=h5eee18b_1
  - zlib=1.2.13=h5eee18b_0
  - pip:
      - absl-py==1.4.0
      - cachetools==5.3.0
      - charset-normalizer==2.1.1
      - docopt==0.6.2
      - easydict==1.10
      - google-auth==2.16.2
      - google-auth-oauthlib==0.4.6
      - grpcio==1.51.3
      - idna==3.4
      - imageio==2.26.0
      - importlib-metadata==6.0.0
      - kornia==0.6.8
      - lpips==0.1.4
      - markdown==3.4.1
      - markupsafe==2.1.2
      - networkx==3.0
      - numpy==1.23.4
      - oauthlib==3.2.2
      - opencv-python==4.6.0.66
      - packaging==23.0
      - pillow==9.4.0
      - pipreqs==0.4.13
      - protobuf==3.20.1
      - pyasn1==0.4.8
      - pyasn1-modules==0.2.8
      - pywavelets==1.4.1
      - pyyaml==6.0
      - requests==2.28.1
      - requests-oauthlib==1.3.1
      - rsa==4.9
      - scikit-image==0.19.3
      - scipy==1.10.1
      - six==1.16.0
      - tensorboard==2.8.0
      - tensorboard-data-server==0.6.1
      - tensorboard-plugin-wit==1.8.1
      - tifffile==2023.2.28
      - torch==1.12.1
      - torchaudio==0.12.1
      - torchvision==0.13.1
      - tqdm==4.64.1
      - typing-extensions==4.5.0
      - urllib3==1.26.14
      - werkzeug==2.2.3
      - yarg==0.1.9
      - zipp==3.15.0
prefix: /home/likaide/anaconda3/envs/WhatMark_wxs
" > requirements.yml

mamba env create -f requirements.yml -y

rm -rf requirements.yml

conda activate WhatMark_wxs

mamba install transformers tabulate pandas numpy gdown -c conda-forge -y
pip uninstall torch torchvision -y
pip install torch==1.12.1+cu113 torchvision==0.13.1+cu113 --extra-index-url https://download.pytorch.org/whl/cu113
pip install uv
uv pip install torchmetrics