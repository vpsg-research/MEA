7z a SepMark-weight.7z \
"results/FullFineTuningWithOnlyMessage/models/D_100.pth" \
"results/FullFineTuningWithOnlyMessage/models/D_108.pth" \
"results/FullFineTuningWithOnlyMessage/models/D_115.pth" \
"results/FullFineTuningWithOnlyMessage/models/EC_100.pth" \
"results/FullFineTuningWithOnlyMessage/models/EC_108.pth" \
"results/FullFineTuningWithOnlyMessage/models/EC_115.pth" && \
rclone copy SepMark-weight.7z gdrive:ModelWeights -P && \
rm SepMark-weight.7z