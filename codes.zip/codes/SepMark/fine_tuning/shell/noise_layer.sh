cd /root/autodl-tmp/Multi-Watermarking/Code/SepMark/network/noise_layers
gdown --folder https://drive.google.com/drive/folders/1doUv70esRjqQGGGWQrbUsCG3IH9TnsNF?usp=drive_link