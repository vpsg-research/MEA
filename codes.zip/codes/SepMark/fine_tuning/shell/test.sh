cd /root/autodl-tmp/Multi-Watermarking/Code/SepMark
conda activate WhatMark_wxs

python fine_tuning/test.py