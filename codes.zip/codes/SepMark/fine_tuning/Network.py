from network.Dual_Mark import *
from transformers import get_cosine_schedule_with_warmup

class FineTuningNetwork(Network):
    def __init__(self, message_length, noise_layers_R, noise_layers_F, device, batch_size, lr, beta1, attention_encoder, attention_decoder, weight, message_range, num_warmup_steps=10, num_training_steps=1000):
        super().__init__(message_length, noise_layers_R, noise_layers_F, device, batch_size, lr, beta1, attention_encoder, attention_decoder, weight)
        self.message_length = message_length
        self.message_range = message_range
        
        self.scheduler = get_cosine_schedule_with_warmup(self.opt_encoder_decoder,   
                                            num_warmup_steps=num_warmup_steps,  
                                            num_training_steps=num_training_steps) 
        
        self.double_encoded_images_diff_weight = 5.0
        self.double_message_weight = 1.0
        self.double_message_weight_R = 0.1
        self.double_message_weight_F = 0.1
        
        self.g_loss_on_double_watermark_weight = 10.0
        self.batch_size = batch_size

    
    def train(self, images: torch.Tensor, messages: torch.Tensor, masks: torch.Tensor):
        self.encoder_decoder.train()
        self.discriminator.train()

        with torch.enable_grad():
            # use device to compute
            images, messages, masks = images.to(self.device), messages.to(self.device), masks.to(self.device)
            encoded_images, noised_images, decoded_messages_C, decoded_messages_R, decoded_messages_F = self.encoder_decoder(images, messages, masks) 

            # ======================= Train discriminator ====================== #
            for p in self.discriminator.parameters():
                p.requires_grad = True

            self.opt_discriminator.zero_grad()

            # RAW : target label for image should be "cover"(1)
            d_label_cover = self.discriminator(images)
            #d_cover_loss = self.criterion_MSE(d_label_cover, torch.ones_like(d_label_cover))
            #d_cover_loss.backward()

            # GAN : target label for encoded image should be "encoded"(0)
            d_label_encoded = self.discriminator(encoded_images.detach())
            #d_encoded_loss = self.criterion_MSE(d_label_encoded, torch.zeros_like(d_label_encoded))
            #d_encoded_loss.backward()

            d_loss = self.criterion_MSE(d_label_cover - torch.mean(d_label_encoded), self.label_cover * torch.ones_like(d_label_cover)) +\
                     self.criterion_MSE(d_label_encoded - torch.mean(d_label_cover), self.label_encoded * torch.ones_like(d_label_encoded))
            d_loss.backward()

            self.opt_discriminator.step()

            # ==================== Train encoder and decoder =================== #
            # Make it a tiny bit faster
            for p in self.discriminator.parameters():
                p.requires_grad = False

            self.opt_encoder_decoder.zero_grad()

            # GAN : target label for encoded image should be "cover"(0)
            g_label_cover = self.discriminator(images)
            g_label_encoded = self.discriminator(encoded_images)
            g_loss_on_discriminator = self.criterion_MSE(g_label_cover - torch.mean(g_label_encoded), self.label_encoded * torch.ones_like(g_label_cover)) +\
                                      self.criterion_MSE(g_label_encoded - torch.mean(g_label_cover), self.label_cover * torch.ones_like(g_label_encoded))

            # RAW : the encoded image should be similar to cover image
            g_loss_on_encoder_MSE = self.criterion_MSE(encoded_images, images)
            g_loss_on_encoder_LPIPS = torch.mean(self.criterion_LPIPS(encoded_images, images))

            # RESULT : the decoded message should be similar to the raw message /Dual
            g_loss_on_decoder_C = self.criterion_MSE(decoded_messages_C, messages)
            g_loss_on_decoder_R = self.criterion_MSE(decoded_messages_R, messages)
            g_loss_on_decoder_F = self.criterion_MSE(decoded_messages_F, torch.zeros_like(messages))
   
            # ======================= Double watermarking ====================== #
            double_message = torch.Tensor(np.random.choice([-self.message_range, self.message_range], (images.shape[0], self.message_length))).to('cuda')
            double_encoded_images, double_noised_images, double_decoded_messages_C, double_decoded_messages_R, double_decoded_messages_F = self.encoder_decoder(noised_images, double_message, masks)
            g_loss_on_double_watermark = (
                # self.criterion_MSE(double_encoded_images, images) * self.double_encoded_images_diff_weight + 
                self.criterion_MSE(double_decoded_messages_C, messages) * self.double_message_weight + 
                self.criterion_MSE(double_decoded_messages_R, messages) * self.double_message_weight_R + 
                self.criterion_MSE(double_decoded_messages_F, torch.zeros_like(messages)) * self.double_message_weight_F
            )

            # ======================== Define full loss ======================== #
            g_loss = (
                self.discriminator_weight * g_loss_on_discriminator + # L_Ad2
                self.encoder_weight * g_loss_on_encoder_MSE + # L_En
                self.decoder_weight_C * g_loss_on_decoder_C + # L_Tr
                self.decoder_weight_R * g_loss_on_decoder_R + # L_De1
                self.decoder_weight_F * g_loss_on_decoder_F + # L_De2
                g_loss_on_double_watermark * self.g_loss_on_double_watermark_weight # Double watermarking
            )

            g_loss.backward()
            self.opt_encoder_decoder.step()
            self.scheduler.step()

            # psnr
            psnr = - kornia.losses.psnr_loss(encoded_images.detach(), images, 2)

            # ssim
            ssim = 1 - 2 * kornia.losses.ssim_loss(encoded_images.detach(), images, window_size=11, reduction="mean")
            
            # psnr
            double_psnr = - kornia.losses.psnr_loss(double_encoded_images.detach(), images, 2)

            # ssim
            double_ssim = 1 - 2 * kornia.losses.ssim_loss(double_encoded_images.detach(), images, window_size=11, reduction="mean")

        # ================ Decoded message error rate /Dual ================ #
        error_rate_C = self.decoded_message_error_rate_batch(messages, decoded_messages_C)        
        error_rate_R = self.decoded_message_error_rate_batch(messages, decoded_messages_R)
        error_rate_F = self.decoded_message_error_rate_batch(messages, decoded_messages_F)
        double_error_rate_C = self.decoded_message_error_rate_batch(messages, double_decoded_messages_C)        
        double_error_rate_R = self.decoded_message_error_rate_batch(messages, double_decoded_messages_R)
        double_error_rate_F = self.decoded_message_error_rate_batch(messages, double_decoded_messages_F)
        
        # self.scheduler.step(double_error_rate_C) # This scheduler should be placed after epoch instead of step. However, for speed of getting result, I placed it here.

        result = {
            "g_loss": g_loss,
            "error_rate_C": error_rate_C,
            "error_rate_R": error_rate_R,
            "error_rate_F": error_rate_F,
            "psnr": psnr,
            "ssim": ssim,
            "g_loss_on_discriminator": g_loss_on_discriminator,
            "g_loss_on_encoder_MSE": g_loss_on_encoder_MSE,
            "g_loss_on_encoder_LPIPS": g_loss_on_encoder_LPIPS,
            "g_loss_on_decoder_C": g_loss_on_decoder_C,
            "g_loss_on_decoder_R": g_loss_on_decoder_R,
            "g_loss_on_decoder_F": g_loss_on_decoder_F,
            "d_loss": d_loss,
            # ==================== Added double watermarking =================== #
            "g_loss_on_double_watermark": g_loss_on_double_watermark, 
            "double_error_rate_C": double_error_rate_C,
            "double_error_rate_R": double_error_rate_R,
            "double_error_rate_F": double_error_rate_F, 
            "double_psnr": double_psnr, 
            "double_ssim": double_ssim
        }
        return result


    def validation(self, images: torch.Tensor, messages: torch.Tensor, masks: torch.Tensor, encoding_num = 1):
        self.encoder_decoder.eval()
        self.encoder_decoder.module.noise.train()
        self.discriminator.eval()

        with torch.no_grad():
            # use device to compute
            images, messages, masks = images.to(self.device), messages.to(self.device), masks.to(self.device)
            encoded_images, noised_images, decoded_messages_C, decoded_messages_R, decoded_messages_F = self.encoder_decoder(images, messages, masks)

            '''
            validate discriminator
            '''
            # RAW : target label for image should be "cover"(1)
            d_label_cover = self.discriminator(images)
            #d_cover_loss = self.criterion_MSE(d_label_cover, torch.ones_like(d_label_cover))

            # GAN : target label for encoded image should be "encoded"(0)
            d_label_encoded = self.discriminator(encoded_images.detach())
            #d_encoded_loss = self.criterion_MSE(d_label_encoded, torch.zeros_like(d_label_encoded))

            d_loss = self.criterion_MSE(d_label_cover - torch.mean(d_label_encoded), self.label_cover * torch.ones_like(d_label_cover)) +\
                     self.criterion_MSE(d_label_encoded - torch.mean(d_label_cover), self.label_encoded * torch.ones_like(d_label_encoded))

            '''
            validate encoder and decoder
            '''

            # GAN : target label for encoded image should be "cover"(0)
            g_label_cover = self.discriminator(images)
            g_label_encoded = self.discriminator(encoded_images)
            g_loss_on_discriminator = self.criterion_MSE(g_label_cover - torch.mean(g_label_encoded), self.label_encoded * torch.ones_like(g_label_cover)) +\
                                      self.criterion_MSE(g_label_encoded - torch.mean(g_label_cover), self.label_cover * torch.ones_like(g_label_encoded))

            # RAW : the encoded image should be similar to cover image
            g_loss_on_encoder_MSE = self.criterion_MSE(encoded_images, images)
            g_loss_on_encoder_LPIPS = torch.mean(self.criterion_LPIPS(encoded_images, images))

            # RESULT : the decoded message should be similar to the raw message /Dual
            g_loss_on_decoder_C = self.criterion_MSE(decoded_messages_C, messages)
            g_loss_on_decoder_R = self.criterion_MSE(decoded_messages_R, messages)
            g_loss_on_decoder_F = self.criterion_MSE(decoded_messages_F, torch.zeros_like(messages))

            # ======================= Double watermarking ====================== #
            double_encoded_images = noised_images
            for i in range(encoding_num):
                double_message = torch.Tensor(np.random.choice([-self.message_range, self.message_range], (images.shape[0], self.message_length))).to('cuda')
                double_encoded_images, _, double_decoded_messages_C, double_decoded_messages_R, double_decoded_messages_F = self.encoder_decoder(double_encoded_images, double_message, masks)
            g_loss_on_double_watermark = (
                # self.criterion_MSE(double_encoded_images, images) * self.double_encoded_images_diff_weight + 
                self.criterion_MSE(double_decoded_messages_C, messages) * self.double_message_weight + 
                self.criterion_MSE(double_decoded_messages_R, messages) * self.double_message_weight_R + 
                self.criterion_MSE(double_decoded_messages_F, torch.zeros_like(messages)) * self.double_message_weight_F
            )

            # ======================== Define full loss ======================== #
            # unstable g_loss_on_discriminator is not used during validation

            g_loss = (
                0 * g_loss_on_discriminator + 
                self.encoder_weight * g_loss_on_encoder_LPIPS +
                self.decoder_weight_C * g_loss_on_decoder_C + 
                self.decoder_weight_R * g_loss_on_decoder_R + 
                self.decoder_weight_F * g_loss_on_decoder_F + 
                g_loss_on_double_watermark * self.g_loss_on_double_watermark_weight
            )

            # psnr
            psnr = - kornia.losses.psnr_loss(encoded_images.detach(), images, 2)
            # ssim
            ssim = 1 - 2 * kornia.losses.ssim_loss(encoded_images.detach(), images, window_size=11, reduction="mean")
            
            # psnr
            double_psnr = - kornia.losses.psnr_loss(double_encoded_images.detach(), images, 2)
            # ssim
            double_ssim = 1 - 2 * kornia.losses.ssim_loss(double_encoded_images.detach(), images, window_size=11, reduction="mean")

        # ================ Decoded message error rate /Dual ================ #
        error_rate_C = self.decoded_message_error_rate_batch(messages, decoded_messages_C)
        error_rate_R = self.decoded_message_error_rate_batch(messages, decoded_messages_R)
        error_rate_F = self.decoded_message_error_rate_batch(messages, decoded_messages_F)
        double_error_rate_C = self.decoded_message_error_rate_batch(messages, double_decoded_messages_C)
        double_error_rate_R = self.decoded_message_error_rate_batch(messages, double_decoded_messages_R)
        double_error_rate_F = self.decoded_message_error_rate_batch(messages, double_decoded_messages_F)

        result = {
            "g_loss": g_loss,
            "error_rate_C": error_rate_C,
            "error_rate_R": error_rate_R,
            "error_rate_F": error_rate_F,
            "psnr": psnr,
            "ssim": ssim,
            "g_loss_on_discriminator": g_loss_on_discriminator,
            "g_loss_on_encoder_MSE": g_loss_on_encoder_MSE,
            "g_loss_on_encoder_LPIPS": g_loss_on_encoder_LPIPS,
            "g_loss_on_decoder_C": g_loss_on_decoder_C,
            "g_loss_on_decoder_R": g_loss_on_decoder_R,
            "g_loss_on_decoder_F": g_loss_on_decoder_F,
            "d_loss": d_loss, 
            # ==================== Added double watermarking =================== #
            "g_loss_on_double_watermark": g_loss_on_double_watermark, 
            "double_error_rate_C": double_error_rate_C,
            "double_error_rate_R": double_error_rate_R,
            "double_error_rate_F": double_error_rate_F, 
            "double_psnr": double_psnr, 
            "double_ssim": double_ssim
        }

        return result, (images, encoded_images, noised_images)

    def test(self, images: torch.Tensor, messages: torch.Tensor, masks: torch.Tensor, encoding_num = 2):
        self.encoder_decoder.eval()
        self.encoder_decoder.module.noise.train()
        self.discriminator.eval()

        with torch.no_grad():
            # use device to compute
            images, messages, masks = images.to(self.device), messages.to(self.device), masks.to(self.device)
            encoded_images, noised_images, decoded_messages_C, decoded_messages_R, decoded_messages_F = self.encoder_decoder(images, messages, masks)

            '''
            validate discriminator
            '''
            # RAW : target label for image should be "cover"(1)
            d_label_cover = self.discriminator(images)
            #d_cover_loss = self.criterion_MSE(d_label_cover, torch.ones_like(d_label_cover))

            # GAN : target label for encoded image should be "encoded"(0)
            d_label_encoded = self.discriminator(encoded_images.detach())
            #d_encoded_loss = self.criterion_MSE(d_label_encoded, torch.zeros_like(d_label_encoded))

            d_loss = self.criterion_MSE(d_label_cover - torch.mean(d_label_encoded), self.label_cover * torch.ones_like(d_label_cover)) +\
                     self.criterion_MSE(d_label_encoded - torch.mean(d_label_cover), self.label_encoded * torch.ones_like(d_label_encoded))

            '''
            validate encoder and decoder
            '''

            # GAN : target label for encoded image should be "cover"(0)
            g_label_cover = self.discriminator(images)
            g_label_encoded = self.discriminator(encoded_images)
            g_loss_on_discriminator = self.criterion_MSE(g_label_cover - torch.mean(g_label_encoded), self.label_encoded * torch.ones_like(g_label_cover)) +\
                                      self.criterion_MSE(g_label_encoded - torch.mean(g_label_cover), self.label_cover * torch.ones_like(g_label_encoded))

            # RAW : the encoded image should be similar to cover image
            g_loss_on_encoder_MSE = self.criterion_MSE(encoded_images, images)
            g_loss_on_encoder_LPIPS = torch.mean(self.criterion_LPIPS(encoded_images, images))

            # RESULT : the decoded message should be similar to the raw message /Dual
            g_loss_on_decoder_C = self.criterion_MSE(decoded_messages_C, messages)
            g_loss_on_decoder_R = self.criterion_MSE(decoded_messages_R, messages)
            g_loss_on_decoder_F = self.criterion_MSE(decoded_messages_F, torch.zeros_like(messages))

            # ======================= Double watermarking ====================== #
            double_encoded_images = noised_images
            for i in range(encoding_num):
                double_message = torch.Tensor(np.random.choice([-self.message_range, self.message_range], (images.shape[0], self.message_length))).to('cuda')
                double_encoded_images, double_noised_images, double_decoded_messages_C, double_decoded_messages_R, double_decoded_messages_F = self.encoder_decoder(double_encoded_images, double_message, masks)
            g_loss_on_double_watermark = (
                self.criterion_MSE(double_encoded_images, images) * self.double_encoded_images_diff_weight + 
                self.criterion_MSE(double_decoded_messages_C, messages) * self.double_message_weight + 
                self.criterion_MSE(double_decoded_messages_R, messages) * self.double_message_weight_R + 
                self.criterion_MSE(double_decoded_messages_F, torch.zeros_like(messages)) * self.double_message_weight_F
            )

            # ======================== Define full loss ======================== #
            # unstable g_loss_on_discriminator is not used during validation

            g_loss = (
                0 * g_loss_on_discriminator + 
                self.encoder_weight * g_loss_on_encoder_LPIPS +
                self.decoder_weight_C * g_loss_on_decoder_C + 
                self.decoder_weight_R * g_loss_on_decoder_R + 
                self.decoder_weight_F * g_loss_on_decoder_F + 
                g_loss_on_double_watermark * self.g_loss_on_double_watermark_weight
            )

            # psnr
            psnr = - kornia.losses.psnr_loss(encoded_images.detach(), images, 2)

            # ssim
            ssim = 1 - 2 * kornia.losses.ssim_loss(encoded_images.detach(), images, window_size=11, reduction="mean")
            
            # psnr
            double_psnr = - kornia.losses.psnr_loss(double_encoded_images.detach(), images, 2)

            # ssim
            double_ssim = 1 - 2 * kornia.losses.ssim_loss(double_encoded_images.detach(), images, window_size=11, reduction="mean")

        # ================ Decoded message error rate /Dual ================ #
        error_rate_C = self.decoded_message_error_rate_batch(messages, decoded_messages_C)
        error_rate_R = self.decoded_message_error_rate_batch(messages, decoded_messages_R)
        error_rate_F = self.decoded_message_error_rate_batch(messages, decoded_messages_F)
        double_error_rate_C = self.decoded_message_error_rate_batch(messages, double_decoded_messages_C)
        double_error_rate_R = self.decoded_message_error_rate_batch(messages, double_decoded_messages_R)
        double_error_rate_F = self.decoded_message_error_rate_batch(messages, double_decoded_messages_F)

        result = {
            "g_loss": g_loss,
            "error_rate_C": error_rate_C,
            "error_rate_R": error_rate_R,
            "error_rate_F": error_rate_F,
            "psnr": psnr,
            "ssim": ssim,
            "g_loss_on_discriminator": g_loss_on_discriminator,
            "g_loss_on_encoder_MSE": g_loss_on_encoder_MSE,
            "g_loss_on_encoder_LPIPS": g_loss_on_encoder_LPIPS,
            "g_loss_on_decoder_C": g_loss_on_decoder_C,
            "g_loss_on_decoder_R": g_loss_on_decoder_R,
            "g_loss_on_decoder_F": g_loss_on_decoder_F,
            "d_loss": d_loss, 
            # ==================== Added double watermarking =================== #
            "g_loss_on_double_watermark": g_loss_on_double_watermark, 
            "double_error_rate_C": double_error_rate_C,
            "double_error_rate_R": double_error_rate_R,
            "double_error_rate_F": double_error_rate_F,
            "double_psnr": double_psnr, 
            "double_ssim": double_ssim
        }

        return result, (images, encoded_images, noised_images, double_encoded_images)
   