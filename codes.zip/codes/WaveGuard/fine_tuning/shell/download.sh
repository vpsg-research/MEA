PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/WaveGuard && \
cd $PROJECT_PATH && \

rclone copy gdrive:ModelWeights/WaveGuard-weight.7z . -P && \
7z x WaveGuard-weight.7z && \
rm WaveGuard-weight.7z