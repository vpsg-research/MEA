PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/WaveGuard && \
cd $PROJECT_PATH && \

7z a WaveGuard-weight.7z \
exp_highpass/2025.07.18-15.57.25/config.json \
exp_highpass/2025.07.18-15.57.25/metrics_table_err.json \
exp_highpass/2025.07.18-15.57.25/metrics_table_visual.json \
exp_highpass/2025.07.18-15.57.25/metrics.json \
exp_highpass/2025.07.18-15.57.25/metrics.tsv \
exp_highpass/2025.07.18-15.57.25/model_state_8.pth \
exp_highpass/2025.07.24-20.10.50/config.json \
exp_highpass/2025.07.24-20.10.50/metrics_table_err.json \
exp_highpass/2025.07.24-20.10.50/metrics_table_visual.json \
exp_highpass/2025.07.24-20.10.50/metrics.json \
exp_highpass/2025.07.24-20.10.50/metrics.tsv \
exp_highpass/2025.07.24-20.10.50/model_state_16.pth && \

rclone copy WaveGuard-weight.7z gdrive:ModelWeights -P && \
rm WaveGuard-weight.7z