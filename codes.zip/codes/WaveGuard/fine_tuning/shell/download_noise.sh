PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/WaveGuard
cd $PROJECT_PATH/network

gdown --fuzzy https://drive.google.com/file/d/188cj_lp8ljaI--nyXiXMUAC3VyKJgRWZ/view?usp=sharing
7z x noise.zip
rm noise.zip