PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/WaveGuard
export DEBUG=1
unset DEBUG

cd $PROJECT_PATH && \
conda activate waveguard

python fine_tuning/fine_tuning.py