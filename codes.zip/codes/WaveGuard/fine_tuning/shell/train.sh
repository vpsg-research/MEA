PROJECT_PATH=/root/autodl-tmp/Multi-Watermarking/Code/WaveGuard

cd $PROJECT_PATH && \
conda activate waveguard

export DEBUG=1
unset DEBUG

python main.py