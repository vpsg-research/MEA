# ============================= Env library ============================= #
import os
import sys
sys.path.append(os.getcwd())
sys.path.append(os.path.dirname(os.getcwd()))
import torch
from torch.utils.data import DataLoader
import numpy as np
import yaml
from easydict import EasyDict
with open("fine_tuning/fine_tuning.yaml", "r") as f:
    cfg = EasyDict(yaml.load(f, Loader=yaml.SafeLoader))
import cv2
import torchvision
from tqdm import tqdm
import cv2
# ============================== My library ============================= #
from multi_encoding_test.Test import MultiEnTester, getImageOrigin
from utils import DTCWT_highpass
from dataloader.dataset import attrsImgDataset
from fine_tuning import FineTuningNetwork

class Tester(MultiEnTester):
    def __init__(self, name, network_origin, network_double, test_loader, CustomDataset):
        super().__init__(name, network_origin, network_double, test_loader, CustomDataset)
        self.indices_encoder = torch.tensor([0, 2]).to(cfg.device)
        self.indices_decoder_d = torch.tensor([0, 2]).to(cfg.device)
        self.indices_decoder_t = torch.tensor([0, 2, 3, 5]).to(cfg.device)
    
    def calculate_bit_error_rate(self, original_message: torch.Tensor, decoded_message: torch.Tensor) -> float:
        def decoded_message_error_rate(message, decoded_message):
            length = message.shape[0]

            message = message.gt(0)
            decoded_message = decoded_message.gt(0)
            error_rate = float((message != decoded_message).sum().item()) / length
            return error_rate
        error_rate = 0.0
        batch_size = len(original_message)
        for i in range(batch_size):
            error_rate += decoded_message_error_rate(original_message[i], decoded_message[i])
        error_rate /= batch_size
        return error_rate
    
    def generate_message(self, batch_size: int, message_length: int) -> torch.Tensor:
        return torch.Tensor(np.random.choice([-cfg.message_range, cfg.message_range], (batch_size, message_length)))
    
    def encode(self, network, image: torch.Tensor, message: torch.Tensor) -> torch.Tensor:
        Y, U, V, low_pass, high_pass = self.preprocess(image)
        selected_areas_embed = torch.index_select(high_pass[1], 2, self.indices_encoder)[:, :, :, :, :, 0].squeeze(1)
        high_pass[1][:, :, self.indices_encoder, :, :, 0] = network.encoder(selected_areas_embed, message).unsqueeze(1)
        u_embedded = DTCWT_highpass.dtcwt_images_U(low_pass, high_pass)
        watermarked_images = torch.cat([Y, u_embedded, V], dim=1)
        return watermarked_images

    def decode(self, network, image: torch.Tensor):
        Y, U, V, low_pass, high_pass = self.preprocess(image)
        u_embedded = U
         # 对水印图像进行 DT-CWT 分解（不包含低频）
        high_pass_extract = DTCWT_highpass.images_U_dtcwt_without_low(u_embedded)
        # 步骤 2：从高频子带中提取所需的子带方向
        selected_areas_extract = torch.index_select(high_pass_extract[1], 2, self.indices_decoder_t)
        # 步骤 3：去除冗余维度，准备输入解码器
        selected_areas_extract = selected_areas_extract[:, :, :, :, :, 0].squeeze(1)
        message = network.decoder_t(selected_areas_extract)
        return message
    
    def encode_decode(self, network, image: torch.Tensor, message: torch.Tensor):
        watermarked_images = self.encode(network, image, message)
        noised_images = watermarked_images.clone()
        decoded_message = self.decode(network, watermarked_images)
        return watermarked_images, noised_images, decoded_message

    def preprocess(self, images):
        images_Y = images[:, [0], :, :]
        images_U = images[:, [1], :, :]
        images_V = images[:, [2], :, :]
        low_pass, high_pass = DTCWT_highpass.images_U_dtcwt_with_low(images_U)
        return images_Y, images_U, images_V, low_pass, high_pass
    
    def general_save_image(self, image: torch.Tensor, folder: str, name: str):
        torchvision.utils.save_image(tensor=image, fp=os.path.join(folder, name), format='png', nrow=image.shape[0], normalize=False)
    
    def wave_save_image(self, image: torch.Tensor):
        image_yuv = (image + 1) * 127.5
        watermarked_images_np = np.clip(image_yuv.squeeze(0).permute(1, 2, 0).detach().cpu().numpy(), 0, 255).astype(np.uint8)
        watermarked_images_bgr = cv2.cvtColor(watermarked_images_np, cv2.COLOR_YUV2BGR)
        image = cv2.cvtColor(watermarked_images_bgr, cv2.COLOR_BGR2RGB)
        return watermarked_images_bgr
    
    def save_image(self, original_image, watermarked_image, multi_watermarked_image, name, encoding_num, repository = None):
        # Save batch
        for idx, n in enumerate(name):
            cv2.imwrite(os.path.join(repository, n, 'original.png'), self.wave_save_image(original_image[idx]))
            cv2.imwrite(os.path.join(repository, n, 'watermarked', f'{self.name}-1.png'), self.wave_save_image(watermarked_image[idx]))
            cv2.imwrite(os.path.join(repository, n, 'watermarked', f'{self.name}-{encoding_num}.png'), self.wave_save_image(multi_watermarked_image[idx]))

    def test_across_model_encode_specific(self, network, number_mutiple_encoding: int, type: str, name_model: str):
        for i, (image, name, message) in tqdm(enumerate(self.test_loader), total=len(self.test_loader), desc=f'{type} with encoding {number_mutiple_encoding} Testing'):
            batch_size = image.shape[0]
            image = image.to(network.device)
            message = self.generate_message(batch_size, network.message_length).to(network.device)
            encoded_images, noised_images, decoded_messages = self.encode_decode(network, image, message)
            
            # Add multiple watermark
            double_encoded_images = noised_images
            for j in range(number_mutiple_encoding):
                double_message = self.generate_message(batch_size, network.message_length).to(network.device)
                double_encoded_images, _, double_decoded_messages = self.encode_decode(network, double_encoded_images, double_message)

            for idx, n in enumerate(name):
                cv2.imwrite(
                    os.path.join(
                        self.result_adapter.common_result_folder, 
                        name_model, 
                        'repository',
                        type, 
                        n, 
                        'watermarked', 
                        f"{self.name}-{number_mutiple_encoding}.png"
                    ), 
                    self.wave_save_image(double_encoded_images[idx])
                )

class TestDataset(attrsImgDataset):
    def __getitem__(self, index):
        filename, label = self.list[index]
        image = cv2.imread(os.path.join(self.image_dir, filename))

        if image is not None:
            try:
                image = cv2.resize(image, (cfg.image_size, cfg.image_size))
            except cv2.error as e:
                height, width = image.shape[:2]
                print(f"Error resizing image {os.path.join(self.image_dir, filename)} (size: {width}x{height}): {e}")
        else:
            print(f"image is none: {os.path.join(self.image_dir, filename)}")

        image = cv2.cvtColor(image, cv2.COLOR_BGR2YUV)
        image = torch.FloatTensor(image / 127.5 - 1.0)
        if image is not None:
            label_tensor = torch.FloatTensor(label)
            image = image.permute(2, 0, 1)        
        return image, filename[:-4], image

class RepoModelDataset(attrsImgDataset):
    def __init__(self, path, name_model, number_encode):
        super().__init__(path, cfg.image_size, "celebahq")
        self.name_model = name_model
        self.number_encode = number_encode
    
    def preprocess(self):
        """Preprocess the CelebA attribute file."""
        lines = [line.rstrip() for line in open(self.attr_path, "r")]
        all_attr_names = lines[1].split()
        for i, attr_name in enumerate(all_attr_names):
            self.attr2idx[attr_name] = i
            self.idx2attr[i] = attr_name

        lines = lines[2:]

        for i, line in enumerate(lines):
            split = line.split()
            basename = os.path.basename(split[0])
            filename = os.path.splitext(basename)[0]
            values = split[1:]

            label = []
            for attr_name in self.selected_attrs:
                idx = self.attr2idx[attr_name]
                label.append(values[idx] == "1")
        self.list = os.listdir(self.image_dir)

    def __getitem__(self, index):
        filename = self.list[index]
        image = cv2.imread(os.path.join(self.image_dir, filename, "watermarked", f"{self.name_model}-{self.number_encode}.png"))
        try:
            image = cv2.resize(image, (cfg.image_size, cfg.image_size))
        except cv2.error as e:
            height, width = image.shape[:2]
            print(f"Error resizing image {os.path.join(self.image_dir, filename)} (size: {width}x{height}): {e}")

        image = cv2.cvtColor(image, cv2.COLOR_BGR2YUV)
        image = torch.FloatTensor(image / 127.5 - 1.0)
        if image is not None:
            image = image.permute(2, 0, 1)        
        message = torch.from_numpy(np.load(os.path.join(self.image_dir, filename, "message.npy")))
        return image, filename, message

if __name__ == "__main__":
    train_dataset = TestDataset(
        os.path.join(cfg.dataset_path, os.getenv("TEST_MODE")),
        cfg.image_size,
        "celebahq",
    )
    train_dataloader = DataLoader(
        train_dataset,
        batch_size=cfg.batch_size,
        shuffle=True,
        num_workers=0,
        pin_memory=True,
    )
    network_origin = FineTuningNetwork()
    network_origin.resume(cfg.test_resume.origin)
    network_double = FineTuningNetwork()
    network_double.resume(cfg.test_resume.fine_tuned)
    tester = Tester(
        name="WaveGuard", 
        network_origin=network_origin, 
        network_double=network_double, 
        test_loader=train_dataloader, 
        CustomDataset=RepoModelDataset
    )
    tester.test(double_encoding_num=5, gen_summary=True)